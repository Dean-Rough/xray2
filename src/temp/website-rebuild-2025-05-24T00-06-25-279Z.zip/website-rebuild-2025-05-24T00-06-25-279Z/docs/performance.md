# Performance Analysis

Consider these performance metrics when rebuilding the website:

## Scores
- **Performance**: 96%
- **Accessibility**: 85%
- **Seo**: 100%
- **BestPractices**: 96%

## Key Metrics
- **firstContentfulPaint**: {"score":0.99,"value":1107.841}
- **largestContentfulPaint**: {"score":0.91,"value":2420.841}
- **totalBlockingTime**: {"score":0.97,"value":120}
- **cumulativeLayoutShift**: {"score":1,"value":0.029977026316433092}

## Recommendations
- Improve accessibility to ensure the site is usable by everyone
