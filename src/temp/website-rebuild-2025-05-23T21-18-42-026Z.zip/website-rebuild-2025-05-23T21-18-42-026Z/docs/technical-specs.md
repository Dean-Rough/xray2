# Technical Specifications

## Site Structure
- **Total Pages**: 27
- **Technologies**: Standard HTML/CSS/JS
- **Design Patterns**: Standard web patterns

## Page Hierarchy
{
  "0": [
    {
      "url": "https://cavai.com",
      "path": "/",
      "segments": []
    }
  ],
  "1": [
    {
      "url": "https://www.cavai.com/products",
      "path": "/products",
      "segments": [
        "products"
      ]
    },
    {
      "url": "https://www.cavai.com/publishers",
      "path": "/publishers",
      "segments": [
        "publishers"
      ]
    },
    {
      "url": "https://www.cavai.com/blog",
      "path": "/blog",
      "segments": [
        "blog"
      ]
    },
    {
      "url": "https://www.cavai.com/cloud",
      "path": "/cloud",
      "segments": [
        "cloud"
      ]
    },
    {
      "url": "https://www.cavai.com/sustainability",
      "path": "/sustainability",
      "segments": [
        "sustainability"
      ]
    },
    {
      "url": "https://www.cavai.com/retail",
      "path": "/retail",
      "segments": [
        "retail"
      ]
    },
    {
      "url": "https://www.cavai.com/contact",
      "path": "/contact",
      "segments": [
        "contact"
      ]
    },
    {
      "url": "https://www.cavai.com/privacy-policy",
      "path": "/privacy-policy",
      "segments": [
        "privacy-policy"
      ]
    },
    {
      "url": "https://www.cavai.com/our-culture",
      "path": "/our-culture",
      "segments": [
        "our-culture"
      ]
    },
    {
      "url": "https://www.cavai.com/about-us",
      "path": "/about-us",
      "segments": [
        "about-us"
      ]
    },
    {
      "url": "https://www.cavai.com/case-studies",
      "path": "/case-studies",
      "segments": [
        "case-studies"
      ]
    },
    {
      "url": "https://www.cavai.com/creative-gallery",
      "path": "/creative-gallery",
      "segments": [
        "creative-gallery"
      ]
    },
    {
      "url": "https://www.cavai.com/cavai-tv",
      "path": "/cavai-tv",
      "segments": [
        "cavai-tv"
      ]
    },
    {
      "url": "https://www.cavai.com/blog?page=2",
      "path": "/blog",
      "segments": [
        "blog"
      ]
    },
    {
      "url": "https://www.cavai.com/in-the-news",
      "path": "/in-the-news",
      "segments": [
        "in-the-news"
      ]
    },
    {
      "url": "https://www.cavai.com/awards",
      "path": "/awards",
      "segments": [
        "awards"
      ]
    }
  ],
  "2": [
    {
      "url": "https://www.cavai.com/products/conversational-commerce",
      "path": "/products/conversational-commerce",
      "segments": [
        "products",
        "conversational-commerce"
      ]
    },
    {
      "url": "https://www.cavai.com/products/conversational-banner",
      "path": "/products/conversational-banner",
      "segments": [
        "products",
        "conversational-banner"
      ]
    },
    {
      "url": "https://www.cavai.com/products/conversational-video",
      "path": "/products/conversational-video",
      "segments": [
        "products",
        "conversational-video"
      ]
    },
    {
      "url": "https://www.cavai.com/case-studies/vodafone-ziggo",
      "path": "/case-studies/vodafone-ziggo",
      "segments": [
        "case-studies",
        "vodafone-ziggo"
      ]
    },
    {
      "url": "https://www.cavai.com/blog/favorite-creatives-2022",
      "path": "/blog/favorite-creatives-2022",
      "segments": [
        "blog",
        "favorite-creatives-2022"
      ]
    },
    {
      "url": "https://www.cavai.com/case-studies/s-pankki-awareness-campaign",
      "path": "/case-studies/s-pankki-awareness-campaign",
      "segments": [
        "case-studies",
        "s-pankki-awareness-campaign"
      ]
    },
    {
      "url": "https://www.cavai.com/case-studies/tv2-sumo-movie-guide",
      "path": "/case-studies/tv2-sumo-movie-guide",
      "segments": [
        "case-studies",
        "tv2-sumo-movie-guide"
      ]
    },
    {
      "url": "https://www.cavai.com/case-studies/adidas-x-zalando-retro-world",
      "path": "/case-studies/adidas-x-zalando-retro-world",
      "segments": [
        "case-studies",
        "adidas-x-zalando-retro-world"
      ]
    },
    {
      "url": "https://www.cavai.com/case-studies/omo-kjell-tore-talking-to-people",
      "path": "/case-studies/omo-kjell-tore-talking-to-people",
      "segments": [
        "case-studies",
        "omo-kjell-tore-talking-to-people"
      ]
    },
    {
      "url": "https://www.cavai.com/case-studies/bmw-sheer-driving-pleasure-sharing-christmas-cheer",
      "path": "/case-studies/bmw-sheer-driving-pleasure-sharing-christmas-cheer",
      "segments": [
        "case-studies",
        "bmw-sheer-driving-pleasure-sharing-christmas-cheer"
      ]
    }
  ]
}

## Asset Summary
- **Css**: 0 files
- **Javascript**: 0 files
- **Images**: 64 files
- **Fonts**: 0 files
- **Videos**: 0 files
- **Other**: 0 files

## Color Palette
Not specified

## Font Families
Not specified

## Key Features
Not specified
