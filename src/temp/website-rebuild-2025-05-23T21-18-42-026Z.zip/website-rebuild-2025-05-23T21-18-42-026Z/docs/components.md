# Component Analysis

This document provides a detailed analysis of the components identified across the website.


## Navigation Components

Found 1 unique navigation components:


### Navigation 1
- **Source**: https://cavai.com
- **Content Preview**: <nav class="uc-navbar-container uc-navbar-float ft-tertiary z-1 uc-navbar-transparent"></nav>

**Note**: Full component content available in pages/ folder



## Footer Components

Found 1 unique footer components:


### Footer 1
- **Source**: https://cavai.com
- **Content Preview**: <footer class="uc-footer panel py-4 md:py-6 xl:py-9 overflow-hidden" id="uc-footer"></footer>

**Note**: Full component content available in pages/ folder



## Header Components

Found 2 unique header components:


### Header 1
- **Source**: https://cavai.com
- **Content Preview**: <header class="uc-header header-default uc-navbar-sticky-wrap z-999 uc-sticky "></header>

**Note**: Full component content available in pages/ folder


### Header 2
- **Source**: https://cavai.com
- **Content Preview**: <header class="uc-offcanvas-header hstack justify-between items-center pb-2 bg-white dark:bg-gray-900"><div class="uc-logo"><a class="h5 text-none text-gray-900 dark:text-white" href="https://cavai.com/"><img alt="Cavai" loading="lazy" width="149" height="45" decoding="async" data-nimg="1" class="w-32px" style="color:transparent" src="https://cavai.com/assets/images/logo.svg"></a></div><button class="uc-offcanvas-close rtl:end-auto rtl:start-0 m-1 mt-2 icon-3 btn border-0 dark:text-white dark:text-opacity-50 hover:text-primary hover:rotate-90 duration-150 transition-all" type="button"><i class="unicon-close"></i></button></header>



## Sidebar Components

Found 0 unique sidebar components:



## Cards Components

Found 0 unique cards components:



## Forms Components

Found 1 unique forms components:


### Forms 1
- **Source**: https://cavai.com
- **Content Preview**: <form class="vstack gap-2"></form>

**Note**: Full component content available in pages/ folder



## Custom Components

Found 0 unique custom components:



