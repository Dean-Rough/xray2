#!/bin/bash
# Asset Download Script
# Run this script to download all assets from the original website

mkdir -p images css javascript fonts videos other

curl -o "css/website.components.spacer.styles.css" "https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.spacer/3949f1e9-f332-495a-a93b-bdc0630f2917_18/website.components.spacer.styles.css"
curl -o "css/static.css" "https://static1.squarespace.com/static/vta/5c5a519771c10ba3470d8101/versioned-assets/1747670066859-4MQ2ACAI6HS7ADBI0GH1/static.css"
curl -o "images/Comp_2.gif?format=1500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/4dc302dd-6607-4e3f-b350-b876a722a215/Comp_2.gif?format=1500w"
curl -o "images/Marker+Scene+%28Lum+Street+Theatre%29.jpg?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/6e48ea17-1e97-4b51-be49-3a9fec9b33c1/Marker+Scene+%28Lum+Street+Theatre%29.jpg?format=2500w"
curl -o "images/Strathwebsize.png?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/b9bedd9e-a3b1-4b89-97b3-dd1a957e6bd3/Strathwebsize.png?format=2500w"
curl -o "images/DRGwebsize.png?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/68af1506-6aec-4836-b912-0f447d81d435/DRGwebsize.png?format=2500w"
curl -o "images/IGwebsize.png?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/3983b5fa-b926-46a7-aca6-7d976655ed56/IGwebsize.png?format=2500w"
curl -o "images/Heinekenwebsize.png?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/16283045-39f1-40d1-8a1e-f772eaf24cd3/Heinekenwebsize.png?format=2500w"
curl -o "images/G1websize.png?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/249c29d0-c492-4ac9-9115-21c68fe473c8/G1websize.png?format=2500w"
curl -o "images/Punchwebsize.png?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/16047296-0b5b-4db3-8c47-22ee6aa4142a/Punchwebsize.png?format=2500w"
curl -o "images/35-sign-mockup.jpg?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/2697198a-9514-4b67-bbe3-5087f421f922/35-sign-mockup.jpg?format=2500w"
curl -o "images/coaster-mockup-03-3537.jpg?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/19bed601-6bae-4e8a-965c-11ae459a5fa3/coaster-mockup-03-3537.jpg?format=2500w"
curl -o "images/Logo-AlabasterOrig.png?format=2500w" "https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/4150fdca-20c5-49d6-b4c6-703df2ba5804/Logo-AlabasterOrig.png?format=2500w"

echo "Asset download complete!"
