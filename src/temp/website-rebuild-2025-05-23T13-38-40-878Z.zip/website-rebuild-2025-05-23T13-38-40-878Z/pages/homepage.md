500

0

[0](https://www.rough.ink/cart)

[Skip to Content](https://www.rough.ink/#page)

[![Rough](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/4dc302dd-6607-4e3f-b350-b876a722a215/Comp_2.gif?format=1500w)](https://www.rough.ink/)

[Home](https://www.rough.ink/)

[About](https://www.rough.ink/about)

[Portfolio](https://www.rough.ink/our-work)

[Our Feed](https://www.rough.ink/details)

[Blog](https://www.rough.ink/blog)

[Contact](https://www.rough.ink/contact)

[Dash](https://www.roughdash.online/)

[Instagram](https://www.instagram.com/roughdesignstudio/)[hey@rough.ink](mailto:hey@rough.ink)

[Free Consultation](https://calendar.app.google/GsxvCyQPcUodNSTF8)

Open MenuClose Menu

[![Rough](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/4dc302dd-6607-4e3f-b350-b876a722a215/Comp_2.gif?format=1500w)](https://www.rough.ink/)

[Home](https://www.rough.ink/)

[About](https://www.rough.ink/about)

[Portfolio](https://www.rough.ink/our-work)

[Our Feed](https://www.rough.ink/details)

[Blog](https://www.rough.ink/blog)

[Contact](https://www.rough.ink/contact)

[Dash](https://www.roughdash.online/)

[Instagram](https://www.instagram.com/roughdesignstudio/)[hey@rough.ink](mailto:hey@rough.ink)

[Free Consultation](https://calendar.app.google/GsxvCyQPcUodNSTF8)

Open MenuClose Menu

[Home](https://www.rough.ink/)

[About](https://www.rough.ink/about)

[Portfolio](https://www.rough.ink/our-work)

[Our Feed](https://www.rough.ink/details)

[Blog](https://www.rough.ink/blog)

[Contact](https://www.rough.ink/contact)

[Dash](https://www.roughdash.online/)

[Instagram](https://www.instagram.com/roughdesignstudio/)

[hey@rough.ink](mailto:hey@rough.ink)

[Free Consultation](https://calendar.app.google/GsxvCyQPcUodNSTF8)

# Spaces, interiors, brands and digital…

at Rough we offer full concept solutions, utilising a combination of design disciplines – ensuring that your digital space is as refined as your physical space, and your physical space makes the right statement for your brand.

[Learn more](https://www.rough.ink/)

EMBARGO, Glasgow

STRATHCLYDE UNIVERSITY, Glasgow

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/6e48ea17-1e97-4b51-be49-3a9fec9b33c1/Marker+Scene+%28Lum+Street+Theatre%29.jpg?format=2500w)

## It’s what we do...

We’re a small but mighty design lab — specialising in communicating spacial and visual ideas. We create bold interiors and brand-focused identities whilst exploring digital experiences and concept-driven work with a playful, hand-crafted touch.

- Spaces
















We cover everything - interior design, exterior design, architecture, planning, consents and project management.

- Interiors
















Starting with a concept - we create interiors build around brand, ethos and experiences. We specialise in commercial interiors and can maximise the potential of any venue.

- Brands
















Brands are at the heart of what we do, no matter the size of the business - understanding your brand is the foundation from which we’ll build your project

- Digital
















We believe your digital spaces should represent an extension of your physical space. We’ll match your web, menus, socials, promo materials (whatever you need) to your brand.


SELECTED PROJECT PARTNERS

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/b9bedd9e-a3b1-4b89-97b3-dd1a957e6bd3/Strathwebsize.png?format=2500w)

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/68af1506-6aec-4836-b912-0f447d81d435/DRGwebsize.png?format=2500w)

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/3983b5fa-b926-46a7-aca6-7d976655ed56/IGwebsize.png?format=2500w)

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/16283045-39f1-40d1-8a1e-f772eaf24cd3/Heinekenwebsize.png?format=2500w)

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/249c29d0-c492-4ac9-9115-21c68fe473c8/G1websize.png?format=2500w)

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/16047296-0b5b-4db3-8c47-22ee6aa4142a/Punchwebsize.png?format=2500w)

**Duke’s Umbrella**

Brand, concept, interior and digital

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/2697198a-9514-4b67-bbe3-5087f421f922/35-sign-mockup.jpg?format=2500w)

ON-GOING PROJECT, Signage Proposal

BABY GRAND, Glasgow

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/19bed601-6bae-4e8a-965c-11ae459a5fa3/coaster-mockup-03-3537.jpg?format=2500w)

![](https://images.squarespace-cdn.com/content/v1/618140f0105a240c6406409d/4150fdca-20c5-49d6-b4c6-703df2ba5804/Logo-AlabasterOrig.png?format=2500w)

38 Buccleuch Street,

Edinburgh,

EH8 9LP

[contact@rough.ink](mailto:contact@rough.ink)

[(0131) 668 4411](tel:+4401316684411)

#### Hours

Monday – Friday

10am – 6pm

#### Follow

[Instagram](http://instagram.com/roughdesignstudio)