# Performance Analysis

Consider these performance metrics when rebuilding the website:

## Scores
- **Performance**: 36%
- **Accessibility**: 96%
- **Seo**: 100%
- **BestPractices**: 100%

## Key Metrics
- **firstContentfulPaint**: {"score":0.13,"value":4677.7865}
- **largestContentfulPaint**: {"score":0,"value":12870.3215}
- **totalBlockingTime**: {"score":0.21,"value":1171.5}
- **cumulativeLayoutShift**: {"score":1,"value":0}

## Recommendations
- Optimize page load performance to improve user experience
- Reduce First Contentful Paint time to under 1 second
- Optimize Largest Contentful Paint to under 2.5 seconds
- Reduce Total Blocking Time to improve interactivity
