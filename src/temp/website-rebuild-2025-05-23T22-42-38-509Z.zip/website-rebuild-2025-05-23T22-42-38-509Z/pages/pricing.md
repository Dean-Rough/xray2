#### book a demo

#### book a demo

restock

reorder

repeat

[Company](https://repeat.studiofreight.com/company) [Content](https://repeat.studiofreight.com/content) [CPG House](https://repeat.studiofreight.com/cpghouse) [Pricing](https://repeat.studiofreight.com/pricing)

[Login\\
\\
Login\\
\\
Login\\
\\
Login](https://backend.getrepeat.io/sign_in)

[Book a Demo\\
\\
Book a Demo\\
\\
Book a Demo\\
\\
Book a Demo](https://repeat.studiofreight.com/pricing?demo=true)

Menu

# ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3kmionqBkHmtazKD6c5WUW%2Fea3f256fc282367efd805e6fde192e73%2FFrame_48096529.png&w=3840&q=75)    REPEAT    ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F7if7wQNpPRWSDjsYa4aHgF%2F0db64e2e2398f92a376ef1fc4c789a23%2FFrame_48096530.png&w=3840&q=75)        PRICING            How many non-subscription orders do you have?            ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3kmionqBkHmtazKD6c5WUW%2Fea3f256fc282367efd805e6fde192e73%2FFrame_48096529.png&w=3840&q=75)    REPEAT        PRICING    ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F7if7wQNpPRWSDjsYa4aHgF%2F0db64e2e2398f92a376ef1fc4c789a23%2FFrame_48096530.png&w=3840&q=75)        How many non-subscription orders do you have?

### \#\#\# 0 - 3,000 Orders

### \#\#\# 3,001 - 10,000 Orders

### \#\#\# 10,001 - 20,000 Orders

Do you have more than 20,000 orders?

[Book a Demo\\
\\
Book a Demo\\
\\
Book a Demo\\
\\
Book a Demo](https://repeat.studiofreight.com/pricing?demo=true)

\*Some Repeat plans include a monthly variable fee.

## Have questions?

### Do you offer trials?

### How do you define monthly non-subscription orders?

### Do you do month-to-month or annual contracts?

### What happens once I choose a plan?

### What if my price tier changes after subscribing?

### Are there feature differences between each plan?

###### SUBSCRIBE FOR FRESH CONTENT & PRODUCT UPDATES.

Subscribe

Subscribe

Subscribe

Subscribe

PRODUCT

- [FROM EMAIL](https://repeat.studiofreight.com/product/klaviyo-replenishment-flows)
- [FROM SMS](https://repeat.studiofreight.com/product/sms)
- [FROM QR CODES](https://repeat.studiofreight.com/product/qr-codes)
- [SUBSCRIPTION PAGES](https://repeat.studiofreight.com/product/subscription-page)
- [SUPPORT](mailto:cs@getrepeat.io)

COMPANY

- [ABOUT US](https://repeat.studiofreight.com/company)
- [COMMUNITY](https://repeat.studiofreight.com/cpghouse)
- [PARTNERS](https://repeat.partnerpage.io/)
- [GET IN TOUCH](mailto:hello@getrepeat.io)
- [PRIVACY](https://repeat.studiofreight.com/legal/privacy-policy)
- [TERMS](https://repeat.studiofreight.com/legal/terms-of-service)

CONTENT

- [RESOURCE HUB](https://repeat.studiofreight.com/content)
- [BLOG](https://blog.getrepeat.io/)
- [PODCAST](https://open.spotify.com/show/09uTHnBt2GeNbhUtgajCRd?si=a827870e8ef64362)
- [NEWSLETTER](https://repeat.substack.com/)

SOCIAL

- [LINKEDIN](https://www.linkedin.com/company/getrepeat/)
- [TWITTER](https://twitter.com/get_repeat)
- [INSTAGRAM](https://www.instagram.com/getrepeat/)
- [TIKTOK](https://www.tiktok.com/@getrepeat)

©2022 Repeat Inc.