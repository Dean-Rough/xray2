# Performance Analysis

Consider these performance metrics when rebuilding the website:

## Scores
- **Performance**: 91%
- **Accessibility**: 85%
- **Seo**: 100%
- **BestPractices**: 96%

## Key Metrics
- **firstContentfulPaint**: {"score":0.99,"value":1157.611}
- **largestContentfulPaint**: {"score":0.79,"value":2962.7509999999997}
- **totalBlockingTime**: {"score":0.91,"value":183.5}
- **cumulativeLayoutShift**: {"score":0.99,"value":0.041103920255827035}

## Recommendations
- Improve accessibility to ensure the site is usable by everyone
