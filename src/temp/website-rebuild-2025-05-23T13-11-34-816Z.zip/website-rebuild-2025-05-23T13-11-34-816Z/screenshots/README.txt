No screenshots were captured during the scan.

This could be due to:
1. Firecrawl API configuration issues
2. Website blocking screenshot capture
3. API rate limits or timeouts
4. Missing screenshot format in API request

To enable screenshots:
- Verify FIRECRAWL_API_KEY is set correctly
- Check Firecrawl account limits
- Ensure target website allows screenshot capture