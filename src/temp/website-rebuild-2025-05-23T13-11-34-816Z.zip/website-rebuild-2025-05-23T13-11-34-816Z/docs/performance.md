# Performance Analysis

Consider these performance metrics when rebuilding the website:

## Scores
- **Performance**: 33%
- **Accessibility**: 96%
- **Seo**: 100%
- **BestPractices**: 100%

## Key Metrics
- **firstContentfulPaint**: {"score":0.15,"value":4529.48}
- **largestContentfulPaint**: {"score":0,"value":28364.906999999985}
- **totalBlockingTime**: {"score":0.03,"value":2736}
- **cumulativeLayoutShift**: {"score":1,"value":0}

## Recommendations
- Optimize page load performance to improve user experience
- Reduce First Contentful Paint time to under 1 second
- Optimize Largest Contentful Paint to under 2.5 seconds
- Reduce Total Blocking Time to improve interactivity
