# Component Analysis

This document provides a detailed analysis of the components identified across the website.


## Navigation Components

Found 2 unique navigation components:


### Navigation 1
- **Source**: https://rough.ink
- **Content Preview**: <nav class="header-nav-list">
                      


  
    <div class="header-nav-item header-nav-item--collection header-nav-item--active header-nav-item--homepage">
      <a href="https://www.rou...


### Navigation 2
- **Source**: https://rough.ink
- **Content Preview**: <nav class="header-menu-nav-list">
          
        <div data-folder="root" class="header-menu-nav-folder header-menu-nav-folder--active">
            <div class="header-menu-nav-folder-content">
  ...



## Footer Components

Found 1 unique footer components:


### Footer 1
- **Source**: https://rough.ink
- **Content Preview**: <footer class="sections" id="footer-sections" data-footer-sections="">
  
  
  
  
  
  
    
    


  
  


<section data-test="page-section" data-section-theme="light-bold" class="page-section 
    ...



## Header Components

Found 1 unique header components:


### Header 1
- **Source**: https://rough.ink
- **Content Preview**: <header data-test="header" id="header" class="header theme-col--primary" data-section-theme="" data-controller="Header" data-current-styles="{
&quot;layout&quot;: &quot;navRight&quot;,
&quot;action&qu...



## Sidebar Components

Found 0 unique sidebar components:



## Cards Components

Found 0 unique cards components:



## Forms Components

Found 0 unique forms components:



## Custom Components

Found 0 unique custom components:



