# Technical Specifications

## Site Structure
- **Total Pages**: 22
- **Technologies**: Standard HTML/CSS/JS
- **Design Patterns**: Standard web patterns

## Page Hierarchy
{
  "0": [
    {
      "url": "https://rough.ink",
      "path": "/",
      "segments": []
    }
  ],
  "1": [
    {
      "url": "https://www.rough.ink/blog",
      "path": "/blog",
      "segments": [
        "blog"
      ]
    },
    {
      "url": "https://www.rough.ink/home",
      "path": "/home",
      "segments": [
        "home"
      ]
    },
    {
      "url": "https://www.rough.ink/contact",
      "path": "/contact",
      "segments": [
        "contact"
      ]
    },
    {
      "url": "https://www.rough.ink/about",
      "path": "/about",
      "segments": [
        "about"
      ]
    },
    {
      "url": "https://www.rough.ink/details",
      "path": "/details",
      "segments": [
        "details"
      ]
    },
    {
      "url": "https://www.rough.ink/calculator",
      "path": "/calculator",
      "segments": [
        "calculator"
      ]
    },
    {
      "url": "https://www.rough.ink/calc",
      "path": "/calc",
      "segments": [
        "calc"
      ]
    },
    {
      "url": "https://www.rough.ink/dash-privacy-policy",
      "path": "/dash-privacy-policy",
      "segments": [
        "dash-privacy-policy"
      ]
    },
    {
      "url": "https://www.rough.ink/dash-terms-of-service",
      "path": "/dash-terms-of-service",
      "segments": [
        "dash-terms-of-service"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work",
      "path": "/our-work",
      "segments": [
        "our-work"
      ]
    }
  ],
  "2": [
    {
      "url": "https://www.rough.ink/blog/the-art-of-commercial-interior-design",
      "path": "/blog/the-art-of-commercial-interior-design",
      "segments": [
        "blog",
        "the-art-of-commercial-interior-design"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/strathclyde-student-union",
      "path": "/our-work/strathclyde-student-union",
      "segments": [
        "our-work",
        "strathclyde-student-union"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/barologist",
      "path": "/our-work/barologist",
      "segments": [
        "our-work",
        "barologist"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/embargo",
      "path": "/our-work/embargo",
      "segments": [
        "our-work",
        "embargo"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/nonna-said",
      "path": "/our-work/nonna-said",
      "segments": [
        "our-work",
        "nonna-said"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/dukes-umbrella",
      "path": "/our-work/dukes-umbrella",
      "segments": [
        "our-work",
        "dukes-umbrella"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/crescent",
      "path": "/our-work/crescent",
      "segments": [
        "our-work",
        "crescent"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/gost",
      "path": "/our-work/gost",
      "segments": [
        "our-work",
        "gost"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/portoleith",
      "path": "/our-work/portoleith",
      "segments": [
        "our-work",
        "portoleith"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/barolo",
      "path": "/our-work/barolo",
      "segments": [
        "our-work",
        "barolo"
      ]
    },
    {
      "url": "https://www.rough.ink/our-work/black-fox",
      "path": "/our-work/black-fox",
      "segments": [
        "our-work",
        "black-fox"
      ]
    }
  ]
}

## Asset Summary
- **Css**: 3 files
- **Javascript**: 0 files
- **Images**: 11 files
- **Fonts**: 0 files
- **Videos**: 0 files
- **Other**: 0 files

## Color Palette
Not specified

## Font Families
Not specified

## Key Features
Not specified
