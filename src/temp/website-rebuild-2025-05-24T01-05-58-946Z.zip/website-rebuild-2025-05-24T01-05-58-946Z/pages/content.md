#### book a demo

#### book a demo

restock

reorder

repeat

[Company](https://repeat.studiofreight.com/company) [Content](https://repeat.studiofreight.com/content) [CPG House](https://repeat.studiofreight.com/cpghouse) [Pricing](https://repeat.studiofreight.com/pricing)

[Login\\
\\
Login\\
\\
Login\\
\\
Login](https://backend.getrepeat.io/sign_in)

[Book a Demo\\
\\
Book a Demo\\
\\
Book a Demo\\
\\
Book a Demo](https://repeat.studiofreight.com/content?demo=true)

Menu

# Fresh    ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2hrzWHgNHMMjiZ9G6g4x1T%2F759d65a93516d0935f87cc7884529e75%2FFrame_48096364.png&w=3840&q=75)    takes.            ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F30jg3WygRiLT7AC4tdA6Is%2F87baa7fea74fa9de812c13e219072c36%2FGroup_48096082.png&w=3840&q=75)    Never    ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F19STs8Yqpvrv2UtZcrfA9h%2Fcc2c1a8f2167728b1bc5f07d6697bff2%2FFrame_48096366.png&w=3840&q=75)    Stale.        CPG    ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2Fs7aCxxQKs5dSLKMhcIWY1%2F1fe20b6a13501686a194f34ea4166087%2FFrame_48096365.png&w=3840&q=75)    Content.                Fresh            Takes.    ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2hrzWHgNHMMjiZ9G6g4x1T%2F759d65a93516d0935f87cc7884529e75%2FFrame_48096364.png&w=3840&q=75)        ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F30jg3WygRiLT7AC4tdA6Is%2F87baa7fea74fa9de812c13e219072c36%2FGroup_48096082.png&w=3840&q=75)    Never        Stale.    ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F19STs8Yqpvrv2UtZcrfA9h%2Fcc2c1a8f2167728b1bc5f07d6697bff2%2FFrame_48096366.png&w=3840&q=75)        CPG    ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2Fs7aCxxQKs5dSLKMhcIWY1%2F1fe20b6a13501686a194f34ea4166087%2FFrame_48096365.png&w=3840&q=75)        Content.

###### Subscribe for weekly content updates

Subscribe

Subscribe

Subscribe

Subscribe

The Shelf Life

### On The  Air  ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2Fs7aCxxQKs5dSLKMhcIWY1%2F1fe20b6a13501686a194f34ea4166087%2FFrame_48096365.png&w=3840&q=75)

Listen in as Alex and the team bring your favorite CPG personalities to talk about retention, customer experience, and building a CPG brand.

[View All\\
\\
View All\\
\\
View All\\
\\
View All](https://open.spotify.com/show/09uTHnBt2GeNbhUtgajCRd?si=a827870e8ef64362)

[Carter Jensen\\
\\
![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F7rXjeuZcShyjcAch61g49M%2Fd50443be9e8f3dbe5ccbb9e7e9d103c6%2FCarter_headshot.jpeg&w=3840&q=90)\\
\\
**General Mills: How Big CPG uses DTC**](https://blog.getrepeat.io/how-does-big-cpg-think-about-dtc/) [Chandler Dutton\\
\\
![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F6Z9zT7aWKEhC3mmf6Z4VMJ%2Fe87477a1cf84afd1a439a4f8c3eb84d7%2FChandler_headshot.jpeg&w=3840&q=90)\\
\\
**Magic Spoon: Subscription as a Retention Tactic**](https://podcasts.apple.com/us/podcast/put-it-on-repeat-magic-spoons-chandler-dutton/id1596936180?i=1000559857415) [Rebecca Zhou\\
\\
![Repeat podcast episode featuring Soft Services founder Rebecca Zhou](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2R7cTK8KVLOCtn5j4jDtgG%2F3a77f8f14fe1709b41f4a6aa508df4e1%2FRepeat-Resources-Podcast-03-Rebecca-Zhou.jpg&w=3840&q=90)\\
\\
**Soft Services: Thinking Like Your Customer**](https://open.spotify.com/episode/5s5CKztYz96XjPYUs3beBq?si=80697a26771b4ba6)

[View All\\
\\
View All\\
\\
View All\\
\\
View All](https://open.spotify.com/show/09uTHnBt2GeNbhUtgajCRd?si=a827870e8ef64362)

Repeat Blog

### ON THE BLOG  ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2hrzWHgNHMMjiZ9G6g4x1T%2F759d65a93516d0935f87cc7884529e75%2FFrame_48096364.png&w=3840&q=75)

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2hrzWHgNHMMjiZ9G6g4x1T%2F759d65a93516d0935f87cc7884529e75%2FFrame_48096364.png&w=3840&q=75)

Explore the ins and outs of reordering and retention through the lens of CPG brands. The team serves up fresh posts every week.

Subscribe

Subscribe

Subscribe

Subscribe

[How to quickly build a replenishment flow](https://blog.getrepeat.io/how-to-simplify-a-multi-branch-replenishment-flow/) [What's the best conversion point for returning customers?](https://blog.getrepeat.io/where-should-you-send-returning-customers-shopify/) [How to measure your retention strategy with data](https://blog.getrepeat.io/how-do-you-measure-and-improve-your-retention-strategy-with-data/)

[View All\\
\\
View All\\
\\
View All\\
\\
View All](https://blog.getrepeat.io/)

Saturdays

### IN YOUR  INBOX  ![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F30jg3WygRiLT7AC4tdA6Is%2F87baa7fea74fa9de812c13e219072c36%2FGroup_48096082.png&w=3840&q=75)

Read about the intersection of CPG, DTC, and consumer behavior every Saturday with Leo. It may surprise you that Leo’s favorite day is actually… Monday.

[Subscribe\\
\\
Subscribe\\
\\
Subscribe\\
\\
Subscribe](https://repeat.substack.com/)

[![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1lw8SURj4bYCv7FOeeVeS4%2Ff8883cc30b0308d76e9c2a55b3d8e989%2FThe_Messy_Middle.jpg&w=3840&q=90)\\
\\
**The Messy Middle** \\
\\
The word retention doesn’t sit quite right when we think about consumer behavior](https://repeat.substack.com/p/messy-middle?s=r) [![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F5qZu6BqwsO0pqJHBUT89Rh%2F779d2aad68f04453eb1f841e5a83b45f%2FLoyalty.jpg&w=3840&q=90)\\
\\
**Loyalty** \\
\\
What we mean when we say “loyalty” can be too vague or misaligned with what’s needed](https://repeat.substack.com/p/loyalty?s=r) [![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F53KjM764HzlQXpaRgNgE7o%2F765a86a8ff1b4e6053b0ccfe2bb6a6f8%2FLaunch.jpg&w=3840&q=90)\\
\\
**Launch** \\
\\
Even in a world where acquisition was the main driver of their business, Bonobos made it easier for their customers to buy again.](https://repeat.substack.com/p/launch)

#### In your feed

[Twitter\\
![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F7wnjezJvHFZDUqJa0J0KA4%2F4e42b3bb73f17f1d914972efbe00a818%2FCard-Twitter.jpg&w=3840&q=90)](https://twitter.com/get_repeat) [Tiktok\\
![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F7izSswvIVTbwUoNdvWwL8v%2Fb2e1b34ab4a851022cdb128ecdbbb67e%2FCard-TikTok.jpg&w=3840&q=90)](https://www.tiktok.com/@getrepeat) [linkedin\\
![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F6HBjEwuuvoOZrk0fOQiKDD%2F7c8b4be922a620eebe054201cead5ad9%2FCard-Linkedin.jpg&w=3840&q=90)](https://www.linkedin.com/company/getrepeat/) [Instagram\\
![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F7Kf3SnA7dpD2C3eIQTp5Nj%2F6327b1219a44385403cc1dd16044580c%2FCard-Instagram.jpg&w=3840&q=90)](https://www.instagram.com/getrepeat/)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

renew

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F15MgH0ycS0jGwTanCQF9rf%2Fa78c89605a42f897186112b8d56dae1e%2FRepeat-CPG-Product-Icon.png&w=3840&q=75)

restock

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F1OpLx41ZKUThbnqCu6NBUM%2F2a90552ab89d316f873e6e9ea5491eb0%2FRepeat-CPG-Product-Icon-2.png&w=3840&q=75)

refill

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F14PqtR37l8eWkLmIQ4UzDe%2Faa20d2f534aa4d831caba2f83d968f59%2FRepeat-CPG-Product-Icon-3.png&w=3840&q=75)

reload

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F3sFlW4VpgV3PAKHcp74XBg%2F6a6162b0499d84ae52f17ea132e9407e%2FRepeat-CPG-Product-Icon-4.png&w=3840&q=75)

refresh

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2FRYCDEkh5MEFQIsL3orwrv%2Ff43bbeb018871e7a078954522d95e253%2FRepeat-CPG-Product-Icon-5.png&w=3840&q=75)

Reorder

![](https://repeat.studiofreight.com/_next/image?url=https%3A%2F%2Fimages.ctfassets.net%2F3owzcimanmiu%2F2KV7nob8WiIFfOpG1fRk7w%2F882e3b2d8fe81d62680ad57462442769%2FRepeat-CPG-Product-Icon-6.png&w=3840&q=75)

###### SUBSCRIBE FOR FRESH CONTENT & PRODUCT UPDATES.

Subscribe

Subscribe

Subscribe

Subscribe

PRODUCT

- [FROM EMAIL](https://repeat.studiofreight.com/product/klaviyo-replenishment-flows)
- [FROM SMS](https://repeat.studiofreight.com/product/sms)
- [FROM QR CODES](https://repeat.studiofreight.com/product/qr-codes)
- [SUBSCRIPTION PAGES](https://repeat.studiofreight.com/product/subscription-page)
- [SUPPORT](mailto:cs@getrepeat.io)

COMPANY

- [ABOUT US](https://repeat.studiofreight.com/company)
- [COMMUNITY](https://repeat.studiofreight.com/cpghouse)
- [PARTNERS](https://repeat.partnerpage.io/)
- [GET IN TOUCH](mailto:hello@getrepeat.io)
- [PRIVACY](https://repeat.studiofreight.com/legal/privacy-policy)
- [TERMS](https://repeat.studiofreight.com/legal/terms-of-service)

CONTENT

- [RESOURCE HUB](https://repeat.studiofreight.com/content)
- [BLOG](https://blog.getrepeat.io/)
- [PODCAST](https://open.spotify.com/show/09uTHnBt2GeNbhUtgajCRd?si=a827870e8ef64362)
- [NEWSLETTER](https://repeat.substack.com/)

SOCIAL

- [LINKEDIN](https://www.linkedin.com/company/getrepeat/)
- [TWITTER](https://twitter.com/get_repeat)
- [INSTAGRAM](https://www.instagram.com/getrepeat/)
- [TIKTOK](https://www.tiktok.com/@getrepeat)

©2022 Repeat Inc.