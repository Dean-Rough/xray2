# Performance Analysis

Consider these performance metrics when rebuilding the website:

## Scores
- **Performance**: 95%
- **Accessibility**: 85%
- **Seo**: 100%
- **BestPractices**: 96%

## Key Metrics
- **firstContentfulPaint**: {"score":0.99,"value":1140.283}
- **largestContentfulPaint**: {"score":0.91,"value":2413.283}
- **totalBlockingTime**: {"score":0.92,"value":175.5}
- **cumulativeLayoutShift**: {"score":0.99,"value":0.041103920255827035}

## Recommendations
- Improve accessibility to ensure the site is usable by everyone
