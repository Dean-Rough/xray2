No CSS files were extracted during the scan.

This could be due to:
1. Website uses inline styles only
2. CSS files are loaded dynamically via JavaScript
3. CSS URLs are relative and couldn't be resolved
4. Network issues during CSS content fetching
5. CSS files are protected or require authentication

To get CSS files:
- Check the original website's developer tools
- Look for CSS links in the HTML files in pages/ folder
- Use the asset manifest to download CSS files manually
