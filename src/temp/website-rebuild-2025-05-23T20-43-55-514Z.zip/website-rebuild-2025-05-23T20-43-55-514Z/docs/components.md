# Component Analysis

This document provides a detailed analysis of the components identified across the website.


## Navigation Components

Found 6 unique navigation components:


### Navigation 1
- **Source**: https://cavai.com
- **Content Preview**: <nav class="uc-navbar-container uc-navbar-float ft-tertiary z-1 uc-navbar-transparent"></nav>

**Note**: Full component content available in pages/ folder


### Navigation 2
- **Source**: https://www.cavai.com/products
- **Content Preview**: <nav class="Header_header__nav__ZRJIJ"><ul class="Header_nav__items__lD2SN"><li class="Header_nav__item__5dBFA Header_active__XpQ1S"><a class="Header_item__name__AG6Mg" href="https://www.cavai.com/products">Products</a><span class="Header_item__line__pTY2S"></span></li><li class="Header_nav__item__5dBFA"><a class="Header_item__name__AG6Mg" href="https://www.cavai.com/cloud">Cavai Cloud</a><span class="Header_item__line__pTY2S"></span></li><li class="Header_nav__item__5dBFA"><a class="Header_item__name__AG6Mg" href="https://www.cavai.com/creative-gallery">Creative Gallery</a><span class="Header_item__line__pTY2S"></span></li><li class="Header_nav__item__5dBFA"><a class="Header_item__name__AG6Mg" href="https://www.cavai.com/case-studies">Cases</a><span class="Header_item__line__pTY2S"></span></li><li class="Header_nav__item__5dBFA"><a class="Header_item__name__AG6Mg" href="https://www.cavai.com/about-us">About us</a><span class="Header_item__line__pTY2S"></span></li></ul></nav>


### Navigation 3
- **Source**: https://www.cavai.com/blog
- **Content Preview**: <nav class="Header_header__nav__ZRJIJ"></nav>

**Note**: Full component content available in pages/ folder


### Navigation 4
- **Source**: https://www.cavai.com/blog
- **Content Preview**: <nav class="Pagination_next-pagination__93vMw"></nav>

**Note**: Full component content available in pages/ folder


### Navigation 5
- **Source**: https://www.cavai.com/about-us
- **Content Preview**: <nav class="OverlayBase_module_overlayNav__b0cfa26d"><button class="CloseOverlayButton_module_closeOverlayButton__bc0b3ddc shared_module_focusableButton__fd03e359" aria-label="Close overlay" data-close-overlay="true"><svg viewBox="0 0 20 20"><path d="M11.06 10l4.597-4.596a.749.749 0 1 0-1.061-1.06L10 8.938 5.404 4.343a.749.749 0 1 0-1.06 1.061L8.938 10l-4.596 4.596a.749.749 0 1 0 1.061 1.06L10 11.062l4.596 4.596a.749.749 0 1 0 1.06-1.061L11.062 10z" fill="#fff" fill-rule="evenodd"></path></svg></button></nav>


### Navigation 6
- **Source**: https://www.cavai.com/blog?page=2
- **Content Preview**: <nav class="Pagination_next-pagination__93vMw"></nav>

**Note**: Full component content available in pages/ folder



## Footer Components

Found 4 unique footer components:


### Footer 1
- **Source**: https://cavai.com
- **Content Preview**: <footer class="uc-footer panel py-4 md:py-6 xl:py-9 overflow-hidden" id="uc-footer"></footer>

**Note**: Full component content available in pages/ folder


### Footer 2
- **Source**: https://www.cavai.com/products
- **Content Preview**: <footer class="Footer_footer__8ba8J"></footer>

**Note**: Full component content available in pages/ folder


### Footer 3
- **Source**: https://www.cavai.com/blog
- **Content Preview**: <footer class="Footer_footer__8ba8J"></footer>

**Note**: Full component content available in pages/ folder


### Footer 4
- **Source**: https://www.cavai.com/privacy-policy
- **Content Preview**: <footer class="Footer_footer__8ba8J"></footer>

**Note**: Full component content available in pages/ folder



## Header Components

Found 12 unique header components:


### Header 1
- **Source**: https://cavai.com
- **Content Preview**: <header class="uc-header header-default uc-navbar-sticky-wrap z-999 uc-sticky "></header>

**Note**: Full component content available in pages/ folder


### Header 2
- **Source**: https://cavai.com
- **Content Preview**: <header class="uc-offcanvas-header hstack justify-between items-center pb-2 bg-white dark:bg-gray-900"><div class="uc-logo"><a class="h5 text-none text-gray-900 dark:text-white" href="https://cavai.com/"><img alt="Cavai" loading="lazy" width="149" height="45" decoding="async" data-nimg="1" class="w-32px" style="color:transparent" src="https://cavai.com/assets/images/logo.svg"></a></div><button class="uc-offcanvas-close rtl:end-auto rtl:start-0 m-1 mt-2 icon-3 btn border-0 dark:text-white dark:text-opacity-50 hover:text-primary hover:rotate-90 duration-150 transition-all" type="button"><i class="unicon-close"></i></button></header>


### Header 3
- **Source**: https://www.cavai.com/products
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder


### Header 4
- **Source**: https://www.cavai.com/publishers
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder


### Header 5
- **Source**: https://www.cavai.com/blog
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder


### Header 6
- **Source**: https://www.cavai.com/cloud
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder


### Header 7
- **Source**: https://www.cavai.com/about-us
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder


### Header 8
- **Source**: https://www.cavai.com/about-us
- **Content Preview**: <header class="Title_module_header__296cb5dd"></header>

**Note**: Full component content available in pages/ folder


### Header 9
- **Source**: https://www.cavai.com/case-studies
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder


### Header 10
- **Source**: https://www.cavai.com/creative-gallery
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder


### Header 11
- **Source**: https://www.cavai.com/blog?page=2
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder


### Header 12
- **Source**: https://www.cavai.com/blog/favorite-creatives-2022
- **Content Preview**: <header class="Header_header__YZ4_L"></header>

**Note**: Full component content available in pages/ folder



## Sidebar Components

Found 0 unique sidebar components:



## Cards Components

Found 13 unique cards components:


### Cards 1
- **Source**: https://www.cavai.com/sustainability
- **Content Preview**: <div class="Wrapper_wrapper__H6ODd Wrapper_wrapper--narrow__k7XsE"><p class="LinksCards_title__y31x0">More on the topic</p><div class="LinksCards_link__cards__ceKEK"><a href="https://research.aalto.fi/en/publications/environmental-impact-assessment-of-online-advertising" target="_blank" class="LinksCards_link__card__eZ8RJ" rel="noreferrer"><div style="transform:translate(0px, 0px)" class="LinksCards_backdrop__irbmd"></div>


### Cards 2
- **Source**: https://www.cavai.com/sustainability
- **Content Preview**: <div class="LinksCards_link__card--image__j0Fzx"></div>

**Note**: Full component content available in pages/ folder


### Cards 3
- **Source**: https://www.cavai.com/sustainability
- **Content Preview**: <div class="LinksCards_link__card--info___pW9X"><p class="LinksCards_link__card--info-title__qsdiP">Environmental impact assessment of online advertising</p><p class="LinksCards_link__card--info-text__u2uE0">There are no commonly agreed ways to assess the total energy consumption of the Internet. Estimating the Internet's energy footprint is challenging because…</p></div>


### Cards 4
- **Source**: https://www.cavai.com/sustainability
- **Content Preview**: <div style="transform:translate(0px, 0px)" class="LinksCards_backdrop__irbmd"></div>


### Cards 5
- **Source**: https://www.cavai.com/sustainability
- **Content Preview**: <div class="LinksCards_link__card--image__j0Fzx"></div>

**Note**: Full component content available in pages/ folder


### Cards 6
- **Source**: https://www.cavai.com/sustainability
- **Content Preview**: <div class="LinksCards_link__card--info___pW9X"><p class="LinksCards_link__card--info-title__qsdiP">Energy Footprint</p><p class="LinksCards_link__card--info-text__u2uE0">Energy footprint is defined by The Global Footprint Network (GFN) (2009), as the sum of all areas used to provide non-food and non-feed energy, such as land used for hydropower, cultivated land for energy and fuel crops…</p></div>


### Cards 7
- **Source**: https://www.cavai.com/retail
- **Content Preview**: <div class="Wrapper_wrapper__H6ODd Wrapper_wrapper--narrow__k7XsE"><p class="LinksCards_title__y31x0">MORE ON THE TOPIC</p><div class="LinksCards_link__cards__ceKEK"><a href="https://www.cavai.com/blog/shopping-assistant" target="_blank" class="LinksCards_link__card__eZ8RJ" rel="noreferrer"><div style="transform:translate(0px, 0px)" class="LinksCards_backdrop__irbmd"></div>


### Cards 8
- **Source**: https://www.cavai.com/retail
- **Content Preview**: <div class="LinksCards_link__card--image__j0Fzx"></div>

**Note**: Full component content available in pages/ folder


### Cards 9
- **Source**: https://www.cavai.com/retail
- **Content Preview**: <div class="LinksCards_link__card--info___pW9X"><p class="LinksCards_link__card--info-title__qsdiP">Virtual shopping assistant explained</p><p class="LinksCards_link__card--info-text__u2uE0">A look into the possibilities that a personal shopping assistant creative gives to the advertisers</p></div>


### Cards 10
- **Source**: https://www.cavai.com/retail
- **Content Preview**: <div class="LinksCards_link__card--image__j0Fzx"></div>

**Note**: Full component content available in pages/ folder


### Cards 11
- **Source**: https://www.cavai.com/retail
- **Content Preview**: <div class="LinksCards_link__card--info___pW9X"><p class="LinksCards_link__card--info-title__qsdiP">Video solution for retail advertisers</p><p class="LinksCards_link__card--info-text__u2uE0">Our reasonings on why conversational video will bring your retail advertising to the next level</p></div>


### Cards 12
- **Source**: https://www.cavai.com/retail
- **Content Preview**: <div class="LinksCards_link__card--image__j0Fzx"></div>

**Note**: Full component content available in pages/ folder


### Cards 13
- **Source**: https://www.cavai.com/retail
- **Content Preview**: <div class="LinksCards_link__card--info___pW9X"><p class="LinksCards_link__card--info-title__qsdiP">Retail case results with Cavai</p><p class="LinksCards_link__card--info-text__u2uE0">A retail case one-pager with amazing results in collaboration with Carrefour and Colgate</p></div>



## Forms Components

Found 7 unique forms components:


### Forms 1
- **Source**: https://cavai.com
- **Content Preview**: <form class="vstack gap-2"></form>

**Note**: Full component content available in pages/ folder


### Forms 2
- **Source**: https://www.cavai.com/products
- **Content Preview**: <form class="Newsletter_newsletter__form__Ozdf_ gform_wrapper"><div class="Newsletter_inputTextGroup__L38VN"><label class="gfield"><span style="background-color:#FFFFFF">Email address</span><input type="text" value=""><button class="Newsletter_form__arrow__CUZ2x"><svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><title>Arrow right</title><g id="icon/expot/button-arrow" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><path d="M7.90339859,-4.61852778e-14 L15.9033986,8 L7.90339859,16 L7.24376293,15.3403643 L14.155,8.428 L-4.33431069e-13,8.42846739 L-4.33431069e-13,7.49560168 L14.08,7.495 L7.24376293,0.659635666 L7.90339859,-4.61852778e-14 Z" id="button-arrow" fill="#000000" fill-rule="nonzero"></path></g></svg></button></label></div></form>


### Forms 3
- **Source**: https://www.cavai.com/blog
- **Content Preview**: <form method="GET" action="" class="Pagination_next-pagination__form__ErUGc"><input type="hidden" name="page" value="1"><label for="next-pagination__size" class="Pagination_next-pagination__label__14fNP">per page</label><div class="Pagination_next-pagination__select___SkZ2"><select name="size" id="next-pagination__size"><option selected="">12</option></select><span><svg class="next-pagination__icon" aria-hidden="true" viewBox="0 0 24 24" width="24" height="24"><path d="M24 24H0V0h24v24z" fill="none" opacity=".87"></path><path fill="currentColor" d="M15.88 9.29L12 13.17 8.12 9.29c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41l4.59 4.59c.39.39 1.02.39 1.41 0l4.59-4.59c.39-.39.39-1.02 0-1.41-.39-.38-1.03-.39-1.42 0z"></path></svg></span></div><button class="Pagination_next-pagination__submit__17C0V" type="submit">Set page size</button></form>


### Forms 4
- **Source**: https://www.cavai.com/cloud
- **Content Preview**: <form class="Newsletter_newsletter__form__Ozdf_ gform_wrapper" data-hs-cf-bound="true"><div class="Newsletter_inputTextGroup__L38VN"><label class="gfield"><span style="background-color:#FFFFFF">Email address</span><input type="text" value=""><button class="Newsletter_form__arrow__CUZ2x"><svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><title>Arrow right</title><g id="icon/expot/button-arrow" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><path d="M7.90339859,-4.61852778e-14 L15.9033986,8 L7.90339859,16 L7.24376293,15.3403643 L14.155,8.428 L-4.33431069e-13,8.42846739 L-4.33431069e-13,7.49560168 L14.08,7.495 L7.24376293,0.659635666 L7.90339859,-4.61852778e-14 Z" id="button-arrow" fill="#000000" fill-rule="nonzero"></path></g></svg></button></label></div></form>


### Forms 5
- **Source**: https://www.cavai.com/about-us
- **Content Preview**: <form class="Newsletter_newsletter__form__Ozdf_ gform_wrapper" data-hs-cf-bound="true"><div class="Newsletter_inputTextGroup__L38VN"><label class="gfield"><span>Email address</span><input type="text" value=""><button class="Newsletter_form__arrow__CUZ2x"><svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><title>Arrow right</title><g id="icon/expot/button-arrow" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><path d="M7.90339859,-4.61852778e-14 L15.9033986,8 L7.90339859,16 L7.24376293,15.3403643 L14.155,8.428 L-4.33431069e-13,8.42846739 L-4.33431069e-13,7.49560168 L14.08,7.495 L7.24376293,0.659635666 L7.90339859,-4.61852778e-14 Z" id="button-arrow" fill="#000000" fill-rule="nonzero"></path></g></svg></button></label></div></form>


### Forms 6
- **Source**: https://www.cavai.com/blog?page=2
- **Content Preview**: <form method="GET" action="" class="Pagination_next-pagination__form__ErUGc" data-hs-cf-bound="true"><input type="hidden" name="page" value="2"><label for="next-pagination__size" class="Pagination_next-pagination__label__14fNP">per page</label><div class="Pagination_next-pagination__select___SkZ2"><select name="size" id="next-pagination__size"><option selected="">12</option></select><span><svg class="next-pagination__icon" aria-hidden="true" viewBox="0 0 24 24" width="24" height="24"><path d="M24 24H0V0h24v24z" fill="none" opacity=".87"></path><path fill="currentColor" d="M15.88 9.29L12 13.17 8.12 9.29c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41l4.59 4.59c.39.39 1.02.39 1.41 0l4.59-4.59c.39-.39.39-1.02 0-1.41-.39-.38-1.03-.39-1.42 0z"></path></svg></span></div><button class="Pagination_next-pagination__submit__17C0V" type="submit">Set page size</button></form>


### Forms 7
- **Source**: https://www.cavai.com/blog/favorite-creatives-2022
- **Content Preview**: <form class="Newsletter_newsletter__form__Ozdf_ gform_wrapper"><div class="Newsletter_inputTextGroup__L38VN"><label class="gfield"><span>Email address</span><input type="text" value=""><button class="Newsletter_form__arrow__CUZ2x"><svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><title>Arrow right</title><g id="icon/expot/button-arrow" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><path d="M7.90339859,-4.61852778e-14 L15.9033986,8 L7.90339859,16 L7.24376293,15.3403643 L14.155,8.428 L-4.33431069e-13,8.42846739 L-4.33431069e-13,7.49560168 L14.08,7.495 L7.24376293,0.659635666 L7.90339859,-4.61852778e-14 Z" id="button-arrow" fill="#000000" fill-rule="nonzero"></path></g></svg></button></label></div></form>



## Custom Components

Found 0 unique custom components:



