#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

FEATURED!adweek

# Ad-Tech Firm Cavai Raises $9 Million as It Eyes US Expansion and IPO

“Historically, creativity has been hard to automate and scale, which is perhaps why the ad industry has placed so much emphasis on hyper-targeting consumers through data, at the expense of the user experience. “

JAN. 11, 2022 [Read moreArrow right](https://www.adweek.com/programmatic/adtech-firm-cavai-raises-9-million-as-it-eyes-us-expansion-and-ipo/)

![adweek logo](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F07%2FAdweek_logo.svg%402.png&w=3840&q=75)

[![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F07%2Flogo3%402.jpeg&w=256&q=75)\\
\\
the drum12 August 2021\\
\\
**Why are marketers so obsessed with Tech? We didn't use to be... Why are marketers so obsessed with Tech? We didn't use to be...**\\
\\
"How long can we as an industry talk about the systems that are powering our digital ads? When print ruled the media world in the 60s, 70s or 80s, did we constantly ponder the printing technology that powered newspaper advertisements?"](https://www.thedrum.com/opinion/2021/09/20/why-are-marketers-obsessed-with-tech-we-didn-t-used-be)

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=gr8a9dlic0qq)