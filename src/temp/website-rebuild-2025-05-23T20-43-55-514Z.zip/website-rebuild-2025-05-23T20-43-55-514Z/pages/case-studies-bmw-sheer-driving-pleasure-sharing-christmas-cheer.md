#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

NEW!Cases \| AUTOMOTIVEDec. 1, 2020

# BMW “Sheer driving pleasure – sharing Christmas cheer”

By making less intrusive ads, we created a more positive and receptive audience.

![BMW “Sheer driving pleasure – sharing Christmas cheer”](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2020%2F12%2FBMW_logo_gray.svg.png&w=3840&q=75)

Background

### After the introduction of GDPR in May 2019, BMW faced a huge challenge in their marketing efforts.

– They could no longer directly communicate with the customer database they had accumulated over the years, without expressed consent.

Targeted marketing (E-mail / SMS) to potential and existing customers, as part of a longer CRM-campaign with several contact points, has proven to be extremely cost-effective for BMW's marketing department. Using this, BMW can increase the likelihood of hitting those who are already in buying mode, increase knowledge of the electric models they offer, and hopefully convert todays Tesla drivers back to The Ultimate Driving Machine. As BMWs customer base was left with a broken back due to GDPR, they had to rebuild it and get customers consent to newsletters/SMS/emails etc. To kick-start it all, BMW set themselves a very high goal - to collect 1 million consents in the Nordic + Baltic countries by the end of 2025. The Norwegian marketing department of BMW set a goal of getting 200,000 consents in the same period to reach their sales targets in the coming years. \*Source: Client solutions DACH

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fbmwtest12.png&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fgoals1.jpg&w=3840&q=75)

OBJECTIVE

### A consent-based customer base of 200,000 by 2025 has become the most important performance target for the Norwegian marketing department of BMW

(\- In addition to selling cars, of course!), and they are looking for digital activities that can build such a customer base. In the past, digital campaigns with a focus on new models and good campaign offers have given very good results, and some of them have been so successful that they have managed to collect up to 2,500 new consents. This time, BMW did not have a new model to show off, so they could not rely on price and product in the campaign. So the question was; How to create a successful campaign, without communicating price nor product?

SOLUTION

### Together we hashed out the idea of a BMW quiz that would help increase knowledge and awareness about the brand.

In collaboration with Good Morning Naug and Vizeum, BMW contacted Cavai with an idea for a Christmas calendar as their new digital activity. Together we hashed out the idea of a BMW quiz that would help increase knowledge and awareness about the brand. Cavai made a proposal for how the combination of a Christmas calendar and quiz could be realised through their advertising platform. Good Morning Naug assisted in crafting the questions and illustrations for the quiz.

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fbmwtest22.png&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fresults.jpg&w=3840&q=75)

RESULTS

### The quiz format proved highly efficient

- 8 out of 10 who opened the quiz window participated further in the quiz by clicking on at least one answer option (If you answer incorrectly, you get the opportunity to start again). With the correct answer, you can click on through to the landing page or try your hand at questions from previous days.
- The vast majority of those who start the Christmas calendar click back through previous questions. For example, if you first opened the ad on December 12, the majority clicked back through previous questions. (Days 11, 10, 9 .. etc.). This shows that the quiz format is very engaging.
- This format has given potential customers an extremely long interaction with the brand. If you know the answer, it will take a minimum of 30 seconds to answer one question and read the answer. Nevertheless, we see that the vast majority click through previous days, responding to more than one question, spending at least 60 seconds within the Christmas quiz.

In total, BMW saw 170,000 different actions in the ad. (Open window - select answer option - return to previous day - click through to landing page)

### Results

60

Seconds spent on average with the quiz

80%

of those who opened the quiz, participated

170000

In-ad actions

Drag

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2020%2F12%2Fthea_sletengen.jpeg&w=3840&q=75)

Thea Sletengen HøghCampaign Manager, Norway, BMW Group

> “I have always wanted to do something a little out of the box that does not directly lead to sales but that creates engagement. After testing Cavai once before, it was an easy choice to challenge them to create something together that could make a bit of a buzz, but which was not necessarily about selling a car. I did not in my wildest imagination think that it would create such a large engagement as this campaign did. I really did not think that so many people would register with personal information that we can now use to inform them about BMW. The campaign has also been noticed in other countries internally, so this will probably become a good tradition in the years to come. ”

Real interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions Diamond

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fadidas_preview.jpg&w=3840&q=100)

Adidas x Zalando

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fblackrock.png&w=3840&q=75)

Blackrock

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fmline.jpg&w=3840&q=100)

M line

## Your ads can do more.

[Let's talkDiamond](https://www.cavai.com/contact)

Case studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamond

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F01%2Fcase_logo-adidas-zalando.png&w=256&q=75)

desktopnativemobile

OMO \|Ecommerce

### Adidas x Zalando – Retro World

[Read more](https://www.cavai.com/case-studies/adidas-x-zalando-retro-world)

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Fomo_case_logo.png&w=256&q=75)

desktopnativemobile

OMO \|Household

### OMO – Kjell & Tore – Talking to people

[Read more](https://www.cavai.com/case-studies/omo-kjell-tore-talking-to-people)

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fspankkilogo.png&w=256&q=75)

desktopnativemobile

S-Pankki \|Banking & Finance

### S-Pankki Awareness Campaign

[Read more](https://www.cavai.com/case-studies/s-pankki-awareness-campaign)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

VodafoneZiggo \|Telco

### VodafoneZiggo “Are you a real F1 fan?”

[Read more](https://www.cavai.com/case-studies/vodafone-ziggo)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

BMW Norway \|Automotive

### BMW “Sheer driving pleasure – sharing Christmas cheer”

[Read more](https://www.cavai.com/case-studies/bmw-sheer-driving-pleasure-sharing-christmas-cheer)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

TV2 Sumo (now TV2 Play) \|Entertainment

### TV2 Sumo “Movie Guide”

[Read more](https://www.cavai.com/case-studies/tv2-sumo-movie-guide)

[See moreArrow right](https://www.cavai.com/case-studies)

Arrow rightArrow right

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=msxdbic9l2tq)