#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

NEW!Cases \| HOUSEHOLDOct. 11, 2022

# OMO – Kjell & Tore – Talking to people

OMO successfully turned around the negative trend with the help of conversational advertising.

![OMO – Kjell & Tore – Talking to people](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Fomo_case_logo.png&w=3840&q=75)

Background

### Doing laundry is not particularly fun or engaging.

After spending decades as the clear market leader, OMO, one of Orkla's laundry detergent brands, was experiencing increased competition,
falling market shares, and a negative trend in brand preference and units sold. To turn things around, the new communications concept of
Kjell & Tore, two green teddy bears from the city of Fredrikstad in southeast Norway, was born in early 2021. The mascots presented a great
opportunity to have some fun in a dry market and once again establish OMO as the trusted laundry expert.

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Fkjell-tore-01.png&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fgoals1.jpg&w=3840&q=75)

OBJECTIVE

### OMO wanted to strengthen its position as the go-to laundry detergent in a fun and engaging way.

**The OMO team decided on three clear goals to uplift their brand:**

1. Strong attention to getting the message out to as many people as possible. The mascots had to be noticed!
2.  Strong brand recognition to ensure the message was tied to OMO.
3. Increased preference for OMO as a measure that they had succeeded on the first 2 points.

There was no doubt dialogue would play a major role in the team's efforts to reach their goals, since the people of southeast Norway, the region where Kjell & Tore are from, are easily recognized by their distinct regional dialect and jovial nature.
In addition to the obvious TV and online video placements, display banners were chosen for their cost-effectiveness to reach a broader
audience. Because the whole concept of Kjell & Tore relied on personality, language and conversation, the OMO team needed to find a
solution where display banners complemented this approach.

SOLUTION

### The solution was a technological innovation, which would provide a platform for Kjell & Tore to shine - conversational advertising.

OMO collaborated with Cavai to develop three different campaigns with several different conversational concepts. All the creative
approaches were tailored to use the mascots in an engaging way and through dialogue and humor, Kjell & Tore could offer helpful information
to the user based on the user's choices.

The first campaign focused on strengthening the perception of OMO being the best at maintaining
colors through a test and a conversation with Tore, while the second campaign was all about sharing information about a specific OMO
product that excels in removing smells. The third and final campaign introduced more interactivity to the campaign in the forms of an in-ad
video and a fun little game where the user helps Tore with refilling his detergent bottle.

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Fkjell-tore-interactivegame.gif&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fresults.jpg&w=3840&q=75)

RESULTS

### After years of a falling market share, together with Cavai, OMO successfully turned around the negative trend.

- 7 of 10 experienced the conversations as entertaining and informative.
- The conversations appeared in banner placements across all of Norway’s key publicists with a total of 35 million impressions.
- With constant optimization throughout, the campaign generated the highest ad attention Cavai has ever measured.

By the third campaign it was evident Kjell & Tore had made the ads easily recognizable as OMO. The company's market share grew by a fantastic
5.7% and the number of units sold increased by 4% through the three campaigns.

### Results

6%

growth in market share

4%

increase in units sold

4%-point

increase in preference for the brand

## Testimonial

Drag

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Forkla-HenrikChristensen-icon.png&w=3840&q=75)

Henrik Christensen Brand Manager, Orkla Home & Personal Care Norway

> We're beyond thrilled with the results from this collaboration, and this new way of making use of classic display placements to communicate with, and not to, consumers.

Real interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions Diamond

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fadidas_preview.jpg&w=3840&q=100)

Adidas x Zalando

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fblackrock.png&w=3840&q=75)

Blackrock

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fmline.jpg&w=3840&q=100)

M line

## Your ads can do more.

[Let's talkDiamond](https://www.cavai.com/contact)

Case studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamond

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F01%2Fcase_logo-adidas-zalando.png&w=256&q=75)

desktopnativemobile

OMO \|Ecommerce

### Adidas x Zalando – Retro World

[Read more](https://www.cavai.com/case-studies/adidas-x-zalando-retro-world)

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Fomo_case_logo.png&w=256&q=75)

desktopnativemobile

OMO \|Household

### OMO – Kjell & Tore – Talking to people

[Read more](https://www.cavai.com/case-studies/omo-kjell-tore-talking-to-people)

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fspankkilogo.png&w=256&q=75)

desktopnativemobile

S-Pankki \|Banking & Finance

### S-Pankki Awareness Campaign

[Read more](https://www.cavai.com/case-studies/s-pankki-awareness-campaign)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

VodafoneZiggo \|Telco

### VodafoneZiggo “Are you a real F1 fan?”

[Read more](https://www.cavai.com/case-studies/vodafone-ziggo)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

BMW Norway \|Automotive

### BMW “Sheer driving pleasure – sharing Christmas cheer”

[Read more](https://www.cavai.com/case-studies/bmw-sheer-driving-pleasure-sharing-christmas-cheer)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

TV2 Sumo (now TV2 Play) \|Entertainment

### TV2 Sumo “Movie Guide”

[Read more](https://www.cavai.com/case-studies/tv2-sumo-movie-guide)

[See moreArrow right](https://www.cavai.com/case-studies)

Arrow rightArrow right

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=jl18yprv46li)