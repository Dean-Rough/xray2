#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [DiamondCases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

NEW!Cases \| ECOMMERCEJan. 11, 2023

# Adidas x Zalando – Retro World

Zalando and Adidas created awareness and traffic through an interactive in-banner game

[Read moreArrow right](https://www.cavai.com/case-studies/adidas-x-zalando-retro-world)

![Adidas x Zalando – Retro World](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F01%2Fcase_logo-adidas-zalando.png&w=3840&q=75)

- All Cases
- Automotive
- Banking & Finance
- Ecommerce
- Entertainment
- Fashion
- Food & Drink
- Government
- Grocery
- Household
- Retail
- Sport
- Technology
- Telco
- Travel
- Utility

[![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F01%2Fcase_logo-adidas-zalando.png&w=256&q=75)\\
\\
desktopnativemobile\\
\\
OMO \|Ecommerce\\
\\
**Adidas x Zalando – Retro World**](https://www.cavai.com/case-studies/adidas-x-zalando-retro-world) [![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Fomo_case_logo.png&w=256&q=75)\\
\\
desktopnativemobile\\
\\
OMO \|Household\\
\\
**OMO – Kjell & Tore – Talking to people**](https://www.cavai.com/case-studies/omo-kjell-tore-talking-to-people) [![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fspankkilogo.png&w=256&q=75)\\
\\
desktopnativemobile\\
\\
S-Pankki \|Banking & Finance\\
\\
**S-Pankki Awareness Campaign**](https://www.cavai.com/case-studies/s-pankki-awareness-campaign) [![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fziggo-vodafone-logo.png&w=256&q=75)\\
\\
desktopnativemobile\\
\\
VodafoneZiggo \|Telco\\
\\
**VodafoneZiggo “Are you a real F1 fan?”**](https://www.cavai.com/case-studies/vodafone-ziggo) [![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2020%2F12%2FBMW_logo_gray.svg.png&w=256&q=75)\\
\\
desktopnativemobile\\
\\
BMW Norway \|Automotive\\
\\
**BMW “Sheer driving pleasure – sharing Christmas cheer”**](https://www.cavai.com/case-studies/bmw-sheer-driving-pleasure-sharing-christmas-cheer) [![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2020%2F03%2FTV2-2021.svg.png&w=256&q=75)\\
\\
desktopnativemobile\\
\\
TV2 Sumo (now TV2 Play) \|Entertainment\\
\\
**TV2 Sumo “Movie Guide”**](https://www.cavai.com/case-studies/tv2-sumo-movie-guide)

## Make your ads do more.

[Let's talkDiamond](https://www.cavai.com/contact)

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=9zufufvt0kaz)