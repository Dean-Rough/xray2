#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

# Privacy Policy

### Last revised August 27, 2020

At Cavai, we take great consideration in securing your personal data. That’s why our advertising products are designed with data privacy in mind from the very beginning, to minimize the amount of personal data collected.

This Privacy Policy has been designed to let you know how Cavai AS (Norway) and Cavai UK Limited (jointly referred to as “Cavai”) process personal data when providing our services, as well as within the scope of our regular business processes.

If you have any questions or comments on this Privacy Policy, please let us know at hello@cav.ai.

## WHEN DO WE PROCESS PERSONAL DATA?

Cavai will process personal data for the following two purposes:

**Purpose 1**

For our regular business processes, such as B2B customer contact, contract conclusions, billing, support, and marketing efforts, we will process personal data of the individuals employed or otherwise engaged by our business partners, vendors, consultants, suppliers, and business customers.

**Purpose 2**

In order to provide the Cavai Studio Reporting Interface for our business customers, we will process personal data to facilitate each user’s access and use of the service. We act as a processor for such processing and concludes data processing agreements with our business customers. We will not process personal data collected as a processor for any other purposes than to provide the Cavai Studio Reporting Interface. Further details regarding processing for this purpose is provided in the Cavai Data Processing Agreement.

### THIS PRIVACY POLICY DESCRIBES OUR PROCESSING OF PERSONAL DATA AS NECESSARY FOR PURPOSE 1 ABOVE.

**When do we not process personal data?**

We will not collect or process any personal data through the Cavai Chatbot Interface. Each of our business customers will themselves determine what personal data to collect (if any) through the Cavai Chatbot Interface. We will assist them in designing and implementing the Cavai Chatbot Interface, but will not store or otherwise have access to any personal data when the Cavai Chatbot Interface has been implemented and taken into use by our business customers.

When you submit personal data to a customer branded Cavai Chatbot Interface, your information and personal data will first be temporarily stored in your terminal equipment (e.g., laptop or mobile phone). When you choose to submit the information and personal data (e.g., by pressing “send” or similar), the information and personal data will be sent directly to a database controlled by our business customers. We do not have any control over or access that information or personal data.

We will only collect anonymous statistical and aggregated data, which does not directly or indirectly identify any individuals.

## HOW WE USE THE COLLECTED PERSONAL DATA

**The personal data we collect is processed for the following purposes:‍**

- Personal Data processed for our regular business processes
- To inform you of updates to our products or services, or changes to this Privacy Policy or other relevant agreements.
- To allow us to provide you with details regarding pricing, functionality, or other features, as well as terms for our products and services.
- To administrate and provide you with our products and services, such as assisting you in implementing our products or services.
- In order to perform billing, as well as contract negotiations and conclusions.
- To troubleshoot and provide support to your use of our products.

We use Hotjar in order to better understand our users’ needs and to optimize this service and experience. Hotjar is a technology service that helps us better understand our users’ experience (e.g. how much time they spend on which pages, which links they choose to click, what users do and don’t like, etc.) and this enables us to build and maintain our service with user feedback. Hotjar uses cookies and other technologies to collect data on our users’ behavior and their devices. This includes a device’s IP address (processed during your session and stored in a de-identified form), device screen size, device type (unique device identifiers), browser information, geographic location (country only), and the preferred language used to display our website. Hotjar stores this information on our behalf in a pseudonymized user profile. Hotjar is contractually forbidden to sell any of the data collected on our behalf. Hotjar affects only the experience accessible through logging into cloud.cavai.com.

## HUBSPOT

On this website we use HubSpot for our online marketing activities. HubSpot is a software company from the USA with a branch office in Ireland. Contact: HubSpot, 2nd Floor 30 North Wall Quay, Dublin 1, Ireland, Telephone: +353 1 5187500.

**This is an integrated software solution that we use to cover different aspects of our online marketing. This includes, among others:**

- Email marketing (newsletter, together with automated mailings, e.g., for provision of downloads), social media publishing & reporting, reporting (e.g., traffic sources, accesses, etc. …), contact management (e.g., user segmentation & CRM), landing pages and contact forms.
- This information, together with the contents of our website are stored on the servers of our software partner HubSpot. We can use it to make contact with visitors to our website and to determine which of our company’s services are interesting for them. All information collected by us is subject to this data privacy policy. We use all information collected exclusively for optimizing our marketing measures.
- The legal basis for the use of HubSpot’s services is article 6 (1) f) GDPR – justified interest. Our justified interest in the use of this service is the optimization of our marketing measures and the improvement of our service quality on the website.
- HubSpot is certified under the conditions of the “EU – U.S. Privacy Shield Framework” and it is subject to TRUSTe’s Privacy Seal, as well as the “U.S. – Swiss Safe Harbor” Framework.

[More information on HubSpot’s data privacy provisions](https://hubspot.com/)

[More information from HubSpot regarding EU data protection provisions](https://hubspot.com/)

[More information on the cookies used by HubSpot can be found here](https://hubspot.com/)

## INFORMATION WE COLLECT, LEGAL BASIS AND RETENTION

**For our regular business processes, we may collect and process the following personal data:**

- Name
- Telephone number
- E-mail address
- Company affiliation and role at the company
- Any potential written correspondence between us
- Information contained within support requests

The legal basis for our processing of such personal data is our legitimate interest to perform our regular business procedures, which we have determined does not override your fundamental rights and freedoms in accordance with article 6 (1) f) of the General Data Protection Regulation (“GDPR”). We will only retain your personal data until it is no longer necessary in order to achieve the processing purposes set out below, or as long as we are required to under statutory legislation.

Cavai uses a session cookie to ensure correct product delivery and function. This cookie does not act to identify a user and is not stored for any longer than 24 hours.

- Cookie Name: connect.sid
- Cookie Value: session ID
- Set Expiration: 24 hours
- Cookie Source: Server-side library
- Purpose: Since our server may be responding to multiple impressions at once, we require a session ID to allow our server to know that the request is part of a specific conversation. This ensures the conversation flows sequentially instead of loading the starting chat bubble repeatedly. This is not used to track or identify users and is expired within 24 hours for reuse.

See below section “Your Rights” for more information.

**To ensure Cavai can provide a reliable service to our clients and end-users several server endpoints are deployed during times of high traffic. These are:**

- deli1.cav.ai
- deli2.cav.ai
- deli3.cav.ai
- delivery-0.cavai.com
- delivery-1.cavai.com
- delivery-2.cavai.com
- delivery-3.cavai.com
- analytics-1.cavai.com
- analytics-2.cavai.com
- analytics-3.cavai.com
- analytics-4.cavai.com

The standard privacy policy applies to all server endpoints, including that relating to cookies and data deletion.

## WHO WE SHARE YOUR INFORMATION WITH

We will not share the personal data of any individuals unless such disclosure is required by statutory legislation which Cavai is subject to.

We will disclose personal data to the other entities within our company group as necessary to carry out the purposes set out in paragraph 3 above. Such disclosure is based on an intra-company data processing agreement all company group entities have entered into.

## YOUR RIGHTS

Any cookies associated with Cavai may be deleted from your browser at any time by clearing your cache. Please see the support instructions for Chrome, Firefox, Safari, or your browser of choice for guidance. You may configure your browser to block any cookies from a specific domain or domains. The domain of our cookie should be listed on your blacklist as cavai.cloud.com or “cavai.studio” or studio.cav.ai.

When providing us with personal data, you may request access to your personal data, as well as additional information on how we process your personal data. You may also request rectification, erasure, and restriction of the processing, as well as to have your personal data exported in a structured, commonly used, and machine-readable format (data portability).

To the extent our processing of personal data is based on your consent, you may withdraw your consent at any time. Withdrawal of consent will not affect the lawfulness of processing based on consent before its withdrawal.

Requests pursuant to the above rights may be submitted to \[email/other instruction for exercising data subject rights\]

You may file a complaint to your applicable data protection authority if you are of the opinion that we have failed to comply with your rights as a data subject.

## CHANGES TO THIS PRIVACY POLICY

We do reserve the right to adjust or change this Privacy Policy as necessary from time to time.

## Sign up for Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=83uq6d6r1d52)