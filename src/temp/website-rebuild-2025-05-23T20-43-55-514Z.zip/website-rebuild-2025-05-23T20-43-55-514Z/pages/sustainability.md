#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

# Advertising has a sustainability problem - Know Your Emissions

To fix the problem, we need to understand the problem. At Cavai, we put considerable resources into understanding how ads emit carbon.

![Advertising has a sustainability problem - Know Your Emissions](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F08%2Fcavai-sustainability-2.svg&w=3840&q=100)

![factory chimney covered with smog](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F07%2Fimage2%402.png&w=3840&q=75)

### Going beyond the standard protocols and ISOs

While following standards such as GHG Protocol and ISO14061 provide a common starting point for every industry, most of online advertising's emissions result from things not covered in such standards.

![1 percent label](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F07%2Fpersonalised-asset%402.png&w=3840&q=75)

### Aiming bigger

Because online advertising already consumes more than 1% of global energy, we believe setting a high standard for our industry is the most significant contribution we can make.

![transparent](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F07%2Fimage3%402.png&w=3840&q=75)

### Impression-level emissions data

Cavai is one of the first online advertising companies to be able to share impression-level carbon emission data on based on a rigorous peer-reviewed scientific framework.

More on the topic

[![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F07%2Flogo2.png&w=3840&q=75)\\
\\
Environmental impact assessment of online advertising\\
\\
There are no commonly agreed ways to assess the total energy consumption of the Internet. Estimating the Internet's energy footprint is challenging because…](https://research.aalto.fi/en/publications/environmental-impact-assessment-of-online-advertising) [![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F07%2Flogo.png&w=3840&q=75)\\
\\
Energy Footprint\\
\\
Energy footprint is defined by The Global Footprint Network (GFN) (2009), as the sum of all areas used to provide non-food and non-feed energy, such as land used for hydropower, cultivated land for energy and fuel crops…](https://www.sciencedirect.com/topics/engineering/energy-footprint)

;

## Learn more about our research on sustainable online advertising

[![Cavai’s Top Tips when Assessing Sustainable Advertising Partners](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F04%2FMoving-Towards-Ecologically-Sustainable-Advertising-The-Actual-Method.png&w=3840&q=75)\\
\\
Blog \| Sustainability\\
\\
Cavai’s Top Tips when Assessing Sustainable Advertising Partners\\
\\
APR. 28, 2023](https://www.cavai.com/blog/tips-to-assess-sustainability-partners)

[![Cavai’s Efforts Towards Sustainable Advertising](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F04%2Fefforts-on-sustainability.png&w=3840&q=75)\\
\\
Blog \| Sustainability\\
\\
Cavai’s Efforts Towards Sustainable Advertising\\
\\
APR. 21, 2023](https://www.cavai.com/blog/cavais-efforts-towards-sustainable-advertising)

[![Is carbon offsetting a viable solution for reaching sustainability goals?](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FIs-carbon-offsetting-a-viable-solution-for-reaching-sustainability-goals_-e1662447472568.png&w=3840&q=75)\\
\\
Blog \| Sustainability\\
\\
Is carbon offsetting a viable solution for reaching sustainability goals?\\
\\
SEPT. 6, 2022](https://www.cavai.com/blog/is-carbon-offsetting-a-viable-solution-for-reaching-sustainability-goals)

[![Moving Towards Ecologically Sustainable Advertising: Introduction](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FMoving-Towards-Ecologically-Sustainable-Advertising-Introduction.png&w=3840&q=75)\\
\\
Blog \| Sustainability\\
\\
Moving Towards Ecologically Sustainable Advertising: Introduction\\
\\
SEPT. 1, 2022](https://www.cavai.com/blog/moving-towards-ecologically-sustainable-advertising-introduction)

[![Moving Towards Ecologically Sustainable Advertising: The Five Fives](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F08%2FSUSTAINABILITY-BIG-FIVE.png&w=3840&q=75)\\
\\
Blog \| Sustainability\\
\\
Moving Towards Ecologically Sustainable Advertising: The Five Fives\\
\\
AUG. 26, 2022](https://www.cavai.com/blog/moving-towards-ecologically-sustainable-advertising-the-five-fives)

Arrow rightArrow right

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=oa7bgyd0gt1p)