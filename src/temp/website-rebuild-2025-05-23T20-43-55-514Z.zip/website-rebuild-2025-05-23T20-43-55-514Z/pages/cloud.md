#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- Products
Products

- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/products_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/products_colour-1.svg)\\
Cavai Products\\
\\
Our conversational products exist in a variety of formats and placements](https://www.cavai.com/products)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cavai_cloud_black-2.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cavai_cloud_colour-2.svg)\\
Cavai Cloud\\
\\
The Cloud is the creative engine where conversations are built and optimized](https://www.cavai.com/cloud)

- Clients
Clients

- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/advertisers_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/advertisers_colour-1.svg)\\
Advertisers\\
\\
How agencies and brands can leverage Cavai's products and services](https://www.cavai.com/advert)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/publishers_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/publishers_colour-1.svg)\\
Publishers\\
\\
How publishers can work with Cavai](https://www.cavai.com/publishers)

- [Creative Gallery](https://www.cavai.com/creative-gallery)
- Resources
Resources



- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/blog_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/blog_colour-1.svg)\\
\\
Blog\\
\\
Updates, insights and best practices](https://www.cavai.com/blog)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cavai_tv_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cavai_tv_colour-1.svg)\\
\\
Cavai TV\\
\\
Client stories, vlogs and other videos from the Cavai community](https://www.cavai.com/cavai-tv)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cases_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cases_colour-1.svg)\\
\\
Cases\\
\\
See what success with Cavai looks like](https://www.cavai.com/case-studies)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2023/03/retail_black.png)![](https://cavai.flywheelsites.com/wp-content/uploads/2023/03/retail_pink.png)\\
\\
Retail\\
\\
Cavai's solutions for retail media](https://www.cavai.com/retail)

[Featured resources![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fcreative_approaches.png&w=640&q=75)Blog post\\
\\
Being creative takes courage. At Cavai, we have put an extensive amount of effort into learning, testing and optimizing creatives….](https://www.cavai.com/blog/conversational-creative-approaches)

- Company
Company



- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/about_us_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/about_us_colour-1.svg)\\
\\
About us\\
\\
What we do and where you can find us](https://www.cavai.com/about-us)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/culture_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/culture_colours-1.svg)\\
\\
Our Culture\\
\\
Who we are and what we're about](https://www.cavai.com/our-culture)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/07/sustainability_icon.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/07/sustainability_hover.svg)\\
\\
Sustainability\\
\\
What are the sustainability facts driving our work](https://www.cavai.com/sustainability)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- Products
  - [Cavai Products](https://www.cavai.com/products)
  - [DiamondCavai Cloud](https://www.cavai.com/cloud)
- Clients
  - [Advertisers](https://www.cavai.com/advert)
  - [Publishers](https://www.cavai.com/publishers)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- Resources
  - [Blog](https://www.cavai.com/blog)
  - [Cavai TV](https://www.cavai.com/cavai-tv)
  - [Cases](https://www.cavai.com/case-studies)
  - [Retail](https://www.cavai.com/retail)
- Company
  - [About us](https://www.cavai.com/about-us)
  - [Our Culture](https://www.cavai.com/our-culture)
  - [Sustainability](https://www.cavai.com/sustainability)

# Cavai Cloud

Cavai Cloud helps you build and deliver conversational advertising experiences on display, mobile, and social, all without relying on cookies.

![Cavai Cloud](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fcavaicloud.png&w=3840&q=100)

## Make better creatives

With the Cloud's component-based decision tree design system, you can design, edit, and even pull reporting, in real-time – without changing how you buy or sell media.

Drag

![](https://cavai.flywheelsites.com/wp-content/uploads/2022/01/megamenu-color-cloud.svg)

### Build ads efficiently

Cavai Cloud allows you to create interactive ads like no other software. Interactions are easily built with drag and drop components and simple copy input capabilities. The flow components show data in real time, and conversation optimization is as easy as just editing the text. All visual elements of the chat can be designed without leaving the tool.

![](https://cavai.flywheelsites.com/wp-content/uploads/2022/01/megamenu-color-partners-1.svg)

### Reduce the need for third-party data

Ads created in Cavai Cloud do not require audience data to deliver results. The tool supports third-party targeting and tracking, but you can have all the benefits of conversational ads without using or collecting audience data.

![](https://cavai.flywheelsites.com/wp-content/uploads/2022/01/megamenu-color-cloud.svg)

### Serve multiple audiences

Conversation-based interaction is a great way to discover different people's needs. A carefully crafted conversation has multiple end points and messages, which can serve varying customer segments in different parts of the sales funnel. With our reporting, you'll gather insights from all these different audiences with one single creative.

## What else can you do with Cavai Cloud?

Make creative formats that can be delivered on all major exchanges, publisher ad servers and media buying technologies. Go beyond conversations with conversational video, ecommerce, in-advertisement payments, in-ad shopping feeds and more.

[Explore our productsArrow right](https://www.cavai.com/products)

Real interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions Diamond

![](<Base64-Image-Removed>)

Adidas x Zalando

![](<Base64-Image-Removed>)

Blackrock

![](<Base64-Image-Removed>)

M line

![](<Base64-Image-Removed>)

SF Studios

![](<Base64-Image-Removed>)

Bol.com x Philips

![](<Base64-Image-Removed>)

Prada

![](<Base64-Image-Removed>)

Discovery Networks

![](<Base64-Image-Removed>)

Intel

![](<Base64-Image-Removed>)

McDonald’s

![](<Base64-Image-Removed>)

VWS

![](<Base64-Image-Removed>)

SF Studio

![](<Base64-Image-Removed>)

OPPO

![](<Base64-Image-Removed>)

Polestar

![](<Base64-Image-Removed>)

TUI

![](<Base64-Image-Removed>)

Intel

![](<Base64-Image-Removed>)

PETPROTECT

![](<Base64-Image-Removed>)

Gjensidige

![](<Base64-Image-Removed>)

Telia

![](<Base64-Image-Removed>)

Transavia

![](<Base64-Image-Removed>)

VWS

![](<Base64-Image-Removed>)

PUIG

![](<Base64-Image-Removed>)

Harley Davidson

![](<Base64-Image-Removed>)

Barceló

![](<Base64-Image-Removed>)

GlaxoSmithKline

![](<Base64-Image-Removed>)

Lay’s

![](<Base64-Image-Removed>)

RI&E

![](<Base64-Image-Removed>)

Aalborg Akvavit

![](<Base64-Image-Removed>)

Bruna

![](<Base64-Image-Removed>)

MG Motor

![](<Base64-Image-Removed>)

Amazon

![](<Base64-Image-Removed>)

LIDL

![](<Base64-Image-Removed>)

Disney+ – 24Kitchen

![](<Base64-Image-Removed>)

Lego

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FGHD-Power-Duo-%E2%80%93-Small-Preview-Image.jpg&w=3840&q=75)

GHD

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2F999-games-Carcassonne-%E2%80%93-Preview-Image.jpg&w=3840&q=75)

999 Games

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FBMW-%E2%80%93-Preview-Image.jpg&w=3840&q=75)

BMW

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fadidas_preview.jpg&w=3840&q=75)

Adidas x Zalando

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fblackrock.png&w=3840&q=75)

Blackrock

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fmline.jpg&w=3840&q=75)

M line

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Felvis.jpg&w=3840&q=75)

SF Studios

![](<Base64-Image-Removed>)

Bol.com x Philips

![](<Base64-Image-Removed>)

Prada

![](<Base64-Image-Removed>)

Discovery Networks

![](<Base64-Image-Removed>)

Intel

![](<Base64-Image-Removed>)

McDonald’s

![](<Base64-Image-Removed>)

VWS

![](<Base64-Image-Removed>)

SF Studio

![](<Base64-Image-Removed>)

OPPO

![](<Base64-Image-Removed>)

Polestar

![](<Base64-Image-Removed>)

TUI

![](<Base64-Image-Removed>)

Intel

![](<Base64-Image-Removed>)

PETPROTECT

![](<Base64-Image-Removed>)

Gjensidige

![](<Base64-Image-Removed>)

Telia

![](<Base64-Image-Removed>)

Transavia

![](<Base64-Image-Removed>)

VWS

![](<Base64-Image-Removed>)

PUIG

![](<Base64-Image-Removed>)

Harley Davidson

![](<Base64-Image-Removed>)

Barceló

![](<Base64-Image-Removed>)

GlaxoSmithKline

![](<Base64-Image-Removed>)

Lay’s

![](<Base64-Image-Removed>)

RI&E

![](<Base64-Image-Removed>)

Aalborg Akvavit

![](<Base64-Image-Removed>)

Bruna

![](<Base64-Image-Removed>)

MG Motor

![](<Base64-Image-Removed>)

Amazon

![](<Base64-Image-Removed>)

LIDL

![](<Base64-Image-Removed>)

Disney+ – 24Kitchen

![](<Base64-Image-Removed>)

Lego

![](<Base64-Image-Removed>)

GHD

![](<Base64-Image-Removed>)

999 Games

![](<Base64-Image-Removed>)

BMW

![](<Base64-Image-Removed>)

Adidas x Zalando

![](<Base64-Image-Removed>)

Blackrock

![](<Base64-Image-Removed>)

M line

![](<Base64-Image-Removed>)

SF Studios

![](<Base64-Image-Removed>)

Bol.com x Philips

![](<Base64-Image-Removed>)

Prada

![](<Base64-Image-Removed>)

Discovery Networks

![](<Base64-Image-Removed>)

Intel

![](<Base64-Image-Removed>)

McDonald’s

![](<Base64-Image-Removed>)

VWS

![](<Base64-Image-Removed>)

SF Studio

![](<Base64-Image-Removed>)

OPPO

![](<Base64-Image-Removed>)

Polestar

![](<Base64-Image-Removed>)

TUI

![](<Base64-Image-Removed>)

Intel

![](<Base64-Image-Removed>)

PETPROTECT

![](<Base64-Image-Removed>)

Gjensidige

![](<Base64-Image-Removed>)

Telia

![](<Base64-Image-Removed>)

Transavia

![](<Base64-Image-Removed>)

VWS

![](<Base64-Image-Removed>)

PUIG

![](<Base64-Image-Removed>)

Harley Davidson

![](<Base64-Image-Removed>)

Barceló

![](<Base64-Image-Removed>)

GlaxoSmithKline

![](<Base64-Image-Removed>)

Lay’s

![](<Base64-Image-Removed>)

RI&E

![](<Base64-Image-Removed>)

Aalborg Akvavit

![](<Base64-Image-Removed>)

Bruna

![](<Base64-Image-Removed>)

MG Motor

![](<Base64-Image-Removed>)

Amazon

![](<Base64-Image-Removed>)

LIDL

![](<Base64-Image-Removed>)

Disney+ – 24Kitchen

![](<Base64-Image-Removed>)

Lego

![](<Base64-Image-Removed>)

GHD

![](<Base64-Image-Removed>)

999 Games

![](<Base64-Image-Removed>)

BMW

[See moreArrow right](https://www.cavai.com/creative-gallery)

## Integrations

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2FRectangle-2%402.png&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Fmessenger-2-Copy-2%402.png&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Fchanneble-2-Copy%402.png&w=3840&q=75)

## Trusted by

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-5-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-6-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-7-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-8-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-9-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-1-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-9-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-8-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-7-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-6-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-5-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-4-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-3-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-2-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-1-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-2-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-3-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-4-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-5-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-6-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-7-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-8-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-9-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-1-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-9-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-8-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-7-copy%402.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F01%2Flogo-6-copy%402.jpg&w=3840&q=75)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

![](<Base64-Image-Removed>)

## Testimonials

Drag

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fpernille-odegaard.png&w=3840&q=75)

Pernille Ødegaard PryserDigital Marketing Lead, Nordea

> We are delighted with the results of our conversational advertising campaign that we did together with Cavai. Not only are we happy with the results, but the collaboration has been fun, professional and very agile.

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fpieter-jadoul.png&w=3840&q=75)

Pieter Jadoul Media Director, AdSomeNoise

> Start having two-way conversations with your consumers, and sharing all the benefits of higher engagement, sales and customer experience

## Your ads can do more.

[Let's talkDiamond](https://www.cavai.com/contact)

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Company

- [About us](https://www.cavai.com/about-us)
- [Our Culture](https://www.cavai.com/our-culture)
- [Sustainability](https://www.cavai.com/sustainability)

Resources

- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=49wjswwzd7lr)