#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- Products
Products

- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/products_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/products_colour-1.svg)\\
Cavai Products\\
\\
Our conversational products exist in a variety of formats and placements](https://www.cavai.com/products)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cavai_cloud_black-2.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cavai_cloud_colour-2.svg)\\
Cavai Cloud\\
\\
The Cloud is the creative engine where conversations are built and optimized](https://www.cavai.com/cloud)

- Clients
Clients

- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/advertisers_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/advertisers_colour-1.svg)\\
Advertisers\\
\\
How agencies and brands can leverage Cavai's products and services](https://www.cavai.com/advert)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/publishers_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/publishers_colour-1.svg)\\
Publishers\\
\\
How publishers can work with Cavai](https://www.cavai.com/publishers)

- [Creative Gallery](https://www.cavai.com/creative-gallery)
- Resources
Resources



- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/blog_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/blog_colour-1.svg)\\
\\
Blog\\
\\
Updates, insights and best practices](https://www.cavai.com/blog)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cavai_tv_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cavai_tv_colour-1.svg)\\
\\
Cavai TV\\
\\
Client stories, vlogs and other videos from the Cavai community](https://www.cavai.com/cavai-tv)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cases_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/cases_colour-1.svg)\\
\\
Cases\\
\\
See what success with Cavai looks like](https://www.cavai.com/case-studies)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2023/03/retail_black.png)![](https://cavai.flywheelsites.com/wp-content/uploads/2023/03/retail_pink.png)\\
\\
Retail\\
\\
Cavai's solutions for retail media](https://www.cavai.com/retail)

[Featured resources![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fcreative_approaches.png&w=640&q=75)Blog post\\
\\
Being creative takes courage. At Cavai, we have put an extensive amount of effort into learning, testing and optimizing creatives….](https://www.cavai.com/blog/conversational-creative-approaches)

- Company
Company



- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/about_us_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/about_us_colour-1.svg)\\
\\
About us\\
\\
What we do and where you can find us](https://www.cavai.com/about-us)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/culture_black-1.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/02/culture_colours-1.svg)\\
\\
Our Culture\\
\\
Who we are and what we're about](https://www.cavai.com/our-culture)
- [![](https://cavai.flywheelsites.com/wp-content/uploads/2022/07/sustainability_icon.svg)![](https://cavai.flywheelsites.com/wp-content/uploads/2022/07/sustainability_hover.svg)\\
\\
Sustainability\\
\\
What are the sustainability facts driving our work](https://www.cavai.com/sustainability)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- Products
  - [Cavai Products](https://www.cavai.com/products)
  - [Cavai Cloud](https://www.cavai.com/cloud)
- Clients
  - [Advertisers](https://www.cavai.com/advert)
  - [Publishers](https://www.cavai.com/publishers)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- Resources
  - [Blog](https://www.cavai.com/blog)
  - [Cavai TV](https://www.cavai.com/cavai-tv)
  - [Cases](https://www.cavai.com/case-studies)
  - [Retail](https://www.cavai.com/retail)
- Company
  - [About us](https://www.cavai.com/about-us)
  - [Our Culture](https://www.cavai.com/our-culture)
  - [Sustainability](https://www.cavai.com/sustainability)

NEW!BLOG \|  Sustainability

# Cavai’s Top Tips when Assessing Sustainable Advertising Partners

The importance of environmental sustainability is more obvious than ever. As more people, companies, brands, and the advertising industry’s supply…

Apr. 28, 2023 \| by KarolSmith

[Read moreArrow right](https://www.cavai.com/blog/tips-to-assess-sustainability-partners)

![Cavai’s Top Tips when Assessing Sustainable Advertising Partners](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F04%2FMoving-Towards-Ecologically-Sustainable-Advertising-The-Actual-Method.png&w=3840&q=75)

- All Articles
- Annoucements
- Conversational Ads
- Insights
- Interactive Ads
- Retail
- Stories
- Sustainability

- [Previous page](https://www.cavai.com/blog?page=1)
- [1](https://www.cavai.com/blog?page=1)
- 2

per page

12

Set page size

## Make your ads do more

[Let's talkDiamond](https://www.cavai.com/contact)

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Company

- [About us](https://www.cavai.com/about-us)
- [Our Culture](https://www.cavai.com/our-culture)
- [Sustainability](https://www.cavai.com/sustainability)

Resources

- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=wlsjgo4x59n9)