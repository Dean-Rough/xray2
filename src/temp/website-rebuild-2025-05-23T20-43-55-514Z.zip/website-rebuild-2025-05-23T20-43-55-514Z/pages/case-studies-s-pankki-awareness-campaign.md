#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

NEW!Cases \| BANKING & FINANCEFeb. 15, 2022

# S-Pankki Awareness Campaign

S-Pankki, Schibsted and Cavai turned out to be the perfect combo to reach new potential customers

![S-Pankki Awareness Campaign](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fspankkilogo.png&w=3840&q=75)

Background

### S-Pankki is reforming the banking industry by offering superior ease and benefits by combining banking and retail services.

S-Pankki is a Finnish bank that was founded as the first supermarket bank in 2006. For S-Pankki, expertise means understanding both the economy and the people.

Tori.fi is Finland’s largest online marketplace, with about 2.7 million unique visitors every month. Owned by Schibsted, it generates nearly 20 000 trades each day. Browsing Tori.fi, you can find products and offers in virtually every category, and the need for quick and easy financing is made immediately apparent.

The combination of S-Pankki’s easy process for acquiring loans without the need for collateral or guarantors and Tori.fi steady supply of consumers looking for financing presents a golden opportunity.

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fs-pankki-1.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fgoals1.jpg&w=3840&q=75)

OBJECTIVE

### S-Pankki decided they wanted to go conversational and got in touch with Cavai.

**2 primary goals were set out for the campaign:**

1. Improve awareness for S-loan as a product

2. Generate high-quality leads


S-Pankki’s S-Loans are loans up to 50 000 €, with no required collateral or guarantor.

People browsing Tori.fi can be assumed to be advanced in the path to purchase. Hitting these consumers at the right time with relevant information was sure to generate quality leads.

However, there was also the need to spread information and awareness of what the product was and how it could help at any point in time where it could be relevant.

Traditional banner ads would struggle to convey a lot of information at once, a different and more creative solution was therefore needed.

SOLUTION

### The conversation was designed to describe the criteria for an S-loan.

The Chat Bubble mimics chat-interfaces that consumers recognize from the major social media.

With a documented effect on clarity of message, trustworthiness and lead-generation it seemed like the perfect solution. However, Tori.fi was not set up for displaying Cavai's ad solutions. Schibsted and Cavai quickly got together, and in short order worked out the details allowing us to place Cavai ads on Tori.fi.

The conversation was designed to describe the criteria for an S-loan and to emphasise the simplicity of the process.

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fs-pankkitesti.png&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fresults.jpg&w=3840&q=75)

RESULTS

### The campaign exceeded expectations

- 2.01% of those exposed interacted with the ad at least once
- 6736 clicked through to the landing page
- 472 people responded they needed a loan, with 73 of those applying for a loan of over 30 000 €
- Although 94% of those interacting with the ad did not have an immediate need for a loan, 267 of those asked for further information on how to apply. This indicated that many are interested in the product and the information, even if the timing is not optimal.

### Results

2.01%

interacted with the ad

472

people responded they needed a loan

73

applied for a loan of over 30 000€

## Testimonial

Drag

Riikka LuomaDigital Marketing Planner, S-Pankki

> “The campaign exceeded our expectations. We wanted to spread awareness about S-loan in the right context and to help the consumers. It was surprising how many actually were interested and continued to s-pankki.fi and applied for a loan. That means we reached the right people at the right time and managed to help them with our product. The collaboration with both Cavai and Schibsted have been very agile and professional. They listened to our needs and hopes and helped us in every step of the way.”

Real interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions Diamond

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fadidas_preview.jpg&w=3840&q=100)

Adidas x Zalando

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fblackrock.png&w=3840&q=75)

Blackrock

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fmline.jpg&w=3840&q=100)

M line

## Your ads can do more.

[Let's talkDiamond](https://www.cavai.com/contact)

Case studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamond

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F01%2Fcase_logo-adidas-zalando.png&w=256&q=75)

desktopnativemobile

OMO \|Ecommerce

### Adidas x Zalando – Retro World

[Read more](https://www.cavai.com/case-studies/adidas-x-zalando-retro-world)

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Fomo_case_logo.png&w=256&q=75)

desktopnativemobile

OMO \|Household

### OMO – Kjell & Tore – Talking to people

[Read more](https://www.cavai.com/case-studies/omo-kjell-tore-talking-to-people)

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fspankkilogo.png&w=256&q=75)

desktopnativemobile

S-Pankki \|Banking & Finance

### S-Pankki Awareness Campaign

[Read more](https://www.cavai.com/case-studies/s-pankki-awareness-campaign)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

VodafoneZiggo \|Telco

### VodafoneZiggo “Are you a real F1 fan?”

[Read more](https://www.cavai.com/case-studies/vodafone-ziggo)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

BMW Norway \|Automotive

### BMW “Sheer driving pleasure – sharing Christmas cheer”

[Read more](https://www.cavai.com/case-studies/bmw-sheer-driving-pleasure-sharing-christmas-cheer)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

TV2 Sumo (now TV2 Play) \|Entertainment

### TV2 Sumo “Movie Guide”

[Read more](https://www.cavai.com/case-studies/tv2-sumo-movie-guide)

[See moreArrow right](https://www.cavai.com/case-studies)

Arrow rightArrow right

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=ggwlzfwthvak)