#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://www.cavai.com/contact)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

![new-year-blog-cover](https://cavai.flywheelsites.com/wp-content/uploads/2022/12/new-year-blog-cover.jpg)

BLOG \|  Conversational Ads

# Cavai’s favorite creatives of 2022

Dec. 14, 2022 \| by

[Arrow rightBack to blog](https://www.cavai.com/blog)

CREATIVITY IS OUR BREAD AND BUTTER

undefined

undefined

undefined

THE CREATIVES

Cavai Converse Iframe

BMW Advent 2022 \| Interactive Creative \| Norway \| Mellina Villanueva, Haakon Mydland

undefined

undefined

undefined

undefined

Cavai Converse Iframe

Prada Paradoxe \| Interactive Banner \| UK \| Gabrielle D’Mello

undefined

undefined

undefined

![](https://cavai.flywheelsites.com/wp-content/uploads/2022/12/subway.gif)

Subway Shrimp Surprise! \| Interactive Chatbox \| Charlotte Cheng

undefined

undefined

undefined

undefined

undefined

Cavai Converse Iframe

Philips for bol.com \| Interactive Banner \| The Netherlands \| Jens Van Egmond

undefined

undefined

undefined

Cavai Converse Iframe

Blackrock Investments \| Interactive Banner \| Charlotte Cheng

undefined

undefined

Cavai Converse Iframe

M line Green Motion \| Conversational Banner \| The Netherlands \| Mitra Kohneseen

undefined

undefined

"The M line campaign ended up with interaction rate and CTR way above benchmarks. Interestingly enough, the two different creative approaches didn’t show significant differences in metrics, which I think in this case means that the attention came from the conversational creative and its appealing interactivity, not the specific wordings."

Mitra Kohneseen \| Conversation Designer \| The Netherlands

undefined

Cavai Converse Iframe

SF Studios Elvis \| Conversational Banner \| Finland \| Eemeli Oksanen

undefined

undefined

undefined

WHAT NEXT?

undefined

undefined

![](https://secure.gravatar.com/avatar/9632617b678aeb820116f0f40cbf947a16ceb3aeb201a5e9b22db983609990e7?s=96&d=mm&r=g)by

SHARE:

Linkedin pageFacebook page

## What we've been up to

[![Cavai’s Top Tips when Assessing Sustainable Advertising Partners](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F04%2FMoving-Towards-Ecologically-Sustainable-Advertising-The-Actual-Method.png&w=3840&q=75)\\
\\
Sustainability\\
\\
Cavai’s Top Tips when Assessing Sustainable Advertising Partners\\
\\
Apr. 28, 2023 \| by](https://www.cavai.com/blog/tips-to-assess-sustainability-partners)

[![Cavai’s Efforts Towards Sustainable Advertising](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F04%2Fefforts-on-sustainability.png&w=3840&q=75)\\
\\
Sustainability\\
\\
Cavai’s Efforts Towards Sustainable Advertising\\
\\
Apr. 21, 2023 \| by](https://www.cavai.com/blog/cavais-efforts-towards-sustainable-advertising)

[![Why I believe in interactive ad tech revolution](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F04%2Four-why.png&w=3840&q=75)\\
\\
Interactive AdsStories\\
\\
Why I believe in interactive ad tech revolution\\
\\
Apr. 11, 2023 \| by](https://www.cavai.com/blog/why-i-believe-in-interactive-ad-tech-revolution)

[![The Journey to Interactive Advertising Success](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F03%2Fconversational-metrics.png&w=3840&q=75)\\
\\
Conversational AdsInteractive Ads\\
\\
The Journey to Interactive Advertising Success\\
\\
Mar. 17, 2023 \| by](https://www.cavai.com/blog/the-journey-to-interactive-advertising-success)

[![Creative solutions for conversational advertising](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fcreative_approaches.png&w=3840&q=75)\\
\\
Conversational Ads\\
\\
Creative solutions for conversational advertising\\
\\
Jan. 20, 2023 \| by](https://www.cavai.com/blog/conversational-creative-approaches)

[![Cavai’s favorite creatives of 2022](<Base64-Image-Removed>)\\
\\
Conversational Ads\\
\\
Cavai’s favorite creatives of 2022\\
\\
Dec. 14, 2022 \| by](https://www.cavai.com/blog/favorite-creatives-2022)

[![Why video ads are perfect for retail advertising](<Base64-Image-Removed>)\\
\\
Conversational AdsRetail\\
\\
Why video ads are perfect for retail advertising\\
\\
Dec. 8, 2022 \| by RogierLammers](https://www.cavai.com/blog/conversational-video-retail)

[![The branded virtual shopping assistant explained](<Base64-Image-Removed>)\\
\\
Conversational AdsRetail\\
\\
The branded virtual shopping assistant explained\\
\\
Dec. 7, 2022 \| by RogierLammers](https://www.cavai.com/blog/shopping-assistant)

[![What are conversational video ads?](<Base64-Image-Removed>)\\
\\
Conversational Ads\\
\\
What are conversational video ads?\\
\\
Nov. 2, 2022 \| by](https://www.cavai.com/blog/what-are-conversational-video-ads)

[![Is carbon offsetting a viable solution for reaching sustainability goals?](<Base64-Image-Removed>)\\
\\
Sustainability\\
\\
Is carbon offsetting a viable solution for reaching sustainability goals?\\
\\
Sept. 6, 2022 \| by](https://www.cavai.com/blog/is-carbon-offsetting-a-viable-solution-for-reaching-sustainability-goals)

[![Moving Towards Ecologically Sustainable Advertising: Introduction](<Base64-Image-Removed>)\\
\\
Sustainability\\
\\
Moving Towards Ecologically Sustainable Advertising: Introduction\\
\\
Sept. 1, 2022 \| by](https://www.cavai.com/blog/moving-towards-ecologically-sustainable-advertising-introduction)

[![Moving Towards Ecologically Sustainable Advertising: The Five Fives](<Base64-Image-Removed>)\\
\\
Sustainability\\
\\
Moving Towards Ecologically Sustainable Advertising: The Five Fives\\
\\
Aug. 26, 2022 \| by](https://www.cavai.com/blog/moving-towards-ecologically-sustainable-advertising-the-five-fives)

[![What are conversational display ads?](<Base64-Image-Removed>)\\
\\
Conversational Ads\\
\\
What are conversational display ads?\\
\\
Aug. 17, 2022 \| by](https://www.cavai.com/blog/what-are-conversational-display-ads)

Arrow rightArrow right

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

reCAPTCHA

Recaptcha requires verification.

[Privacy](https://www.google.com/intl/en/policies/privacy/) \- [Terms](https://www.google.com/intl/en/policies/terms/)

protected by **reCAPTCHA**

[Privacy](https://www.google.com/intl/en/policies/privacy/) \- [Terms](https://www.google.com/intl/en/policies/terms/)