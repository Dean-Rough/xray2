#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [DiamondCreative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

# Creative Gallery

industries

languages

objectives

Reset all filtersreset

Adidas x Zalando

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fadidas_preview.jpg&w=3840&q=100)

Bol.com x Philips

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fphilips.jpg&w=3840&q=100)

McDonald’s

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FMcDonalds_McDelivery-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Polestar

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FPolestar-2-Creative-Preview.jpg&w=3840&q=100)

Gjensidige

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FGjensidige-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

PUIG

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F07%2FPUIG-Jean-Paul-Gartier-%E2%80%93-Preview-Image-1.jpg&w=3840&q=100)

Lay’s

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FLays-Welke-smaak-blijft_-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

MG Motor

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FMG-Motors-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Lego

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FLego-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Blackrock

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fblackrock.png&w=3840&q=100)

Prada

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fprada_paradoxe.jpg&w=3840&q=100)

VWS

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FVWS-Puur-Stoppen-met-roken-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

TUI

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FTUi-travel-info-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Telia

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FTelia-Luurinmetsastyspaivat-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Harley Davidson

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F06%2FHarley-Pan-America-%E2%80%93-Preview-Image-e1655970450788.jpg&w=3840&q=100)

RI&E

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FRIE-Gezond-werken-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Amazon

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FAmazon-Prime-NL-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

GHD

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FGHD-Power-Duo-%E2%80%93-Small-Preview-Image.jpg&w=3840&q=100)

M line

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fmline.jpg&w=3840&q=100)

Discovery Networks

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Ftrue_love_danmark.jpg&w=3840&q=100)

SF Studio

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FSF-Studio-Matrix-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Intel

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FIntel_EVO-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Transavia

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FTransavia-Samen-UIT-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Barceló

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FBarcelo-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Aalborg Akvavit

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FAalborg-Akvavit.jpg&w=3840&q=100)

LIDL

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FLIDL-%E2%80%93-Preview-Image-e1655970977843.jpg&w=3840&q=100)

999 Games

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2F999-games-Carcassonne-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

SF Studios

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Felvis.jpg&w=3840&q=100)

Intel

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fintel_creative_gallery_preview.jpg&w=3840&q=100)

OPPO

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FOppo_A74_creative_preview.jpg&w=3840&q=100)

PETPROTECT

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FRM-PetProtect_creative_preview.jpg&w=3840&q=100)

VWS

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F09%2FVWS-Hey-het-is-oke-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

GlaxoSmithKline

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FOtrason-%E2%80%93-Preview-Image-e1655970948828.jpg&w=3840&q=100)

Bruna

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FBruna-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

Disney+ – 24Kitchen

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2F24Kitchen-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

BMW

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2FBMW-%E2%80%93-Preview-Image.jpg&w=3840&q=100)

## Your ads can do more.

[Let's talkDiamond](https://www.cavai.com/contact)

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=mr9w8eak0tmq)