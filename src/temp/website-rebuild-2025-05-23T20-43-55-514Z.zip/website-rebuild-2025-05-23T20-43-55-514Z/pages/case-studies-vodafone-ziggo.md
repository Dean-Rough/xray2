#### We're privacy first

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. Feel free to decline – it will not affect your viewing of the site.

Go ahead!No thanks

[Cavai logo](https://www.cavai.com/)

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

[Sign inDiamond](https://my.cavai.com/login)

MenuDiamond

- [Products](https://www.cavai.com/products)
- [Cavai Cloud](https://www.cavai.com/cloud)
- [Creative Gallery](https://www.cavai.com/creative-gallery)
- [Cases](https://www.cavai.com/case-studies)
- [About us](https://www.cavai.com/about-us)

NEW!Cases \| TELCOFeb. 7, 2022

# VodafoneZiggo “Are you a real F1 fan?”

Dutch case study for the cable & telco brand

![VodafoneZiggo “Are you a real F1 fan?”](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fziggo-vodafone-logo.png&w=3840&q=75)

Background

### Ziggo provides cable television, radio, internet and phone-services, operating since 2016 under the parent company VodafoneZiggo.

Serving 4 million households with up to 200 channels, it is the Netherlands largest cable provider. Ziggo holds the exclusive Formula 1 rights for the Netherlands.Since Max Verstappen first broke into F1 in 2015 at the age of 17, the sport has seen a major resurgence in popularity. Predicted by many to the heir apparent to Lewis Hamilton as the world’s premier driver, Verstappen has become one of the most beloved sports personalities in the country.Acting to further increase the sports profile, in 2019 it was announced F1 would return to the Zandvoort circuit for the Dutch Grand Prix in 2020. Due to Covid-19, this return was postponed until the 2021-season.With the new season kicking off march 28th in Bahrain, media attention was high. Ziggo saw an opportunity to recruit new subscribers.

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fziggo_1-test.png&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fgoals1.jpg&w=3840&q=75)

OBJECTIVE

### Ziggo holds the exclusive Formula 1-rights for the Netherlands.

Given the increased interest in the sport over the last few years, recruiting new subscribers among F1-fans seemed a tantalizing opportunity.

We wanted to create an engaging experience, increase awareness of Ziggo's position as the Netherlands' only supplier of Formula 1-broadcasts, and generate high-quality leads on potential subscribers. **Goals:**

1. Create engagement and awareness
2. Generate high-quality leads

SOLUTION

### To create engagement with the ad, we know a more informal approach is more effective.

So we decided to allow consumers to have a little fun, showcasing their knowledge of Formula 1 and their ability to predict the coming season.

The goal was to get those interested in Formula 1 to spend a substantial amount of time interacting with Ziggo through the ad.Cavai offers ads contained either within normal banners or the Chat Bubble. The Chat Bubble mimics chat-interfaces that consumers recognize from the major social media.We made 2 different ads. One was a quiz-format and the other gave users a chance to predict what will happen in the 2021-season. Both formats consisted of 3 questions.

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fconversational-approach.jpg&w=3840&q=75)

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fresults.jpg&w=3840&q=75)

RESULTS

### The quiz format proved highly efficient

Overall, the quiz format proved highly efficient at creating engagement, entertaining users while still communicating Ziggos offering to a key demographic. Contextual placements greatly amplified the impact of the conversational format for Ziggo.

- 10 810 people interacted with the ad at least once.
- We saw a total of 32 343 total interactions with the ad, meaning almost everyone actually completed the quiz or predictor
- The average dwell time, the time spent in conversation with the ad was an amazing 56 seconds
- Impressions were delivered both through audience targeting and contextual placements.
- The quality of the traffic driven from contextual placements on this campaign was much higher, up to 5 times more likely to visit one or more pages on the landing site when compared to audience targeting.
- We also saw that contextual targeting had a 30% lower bounce rate than traffic from audience targeting.

### Results

10810

People interacted with the ad

3+

average interactions per person

56

Seconds spent on average interacting with the ad

Real interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions DiamondReal interactions Diamond

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F11%2Fadidas_preview.jpg&w=3840&q=100)

Adidas x Zalando

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fblackrock.png&w=3840&q=75)

Blackrock

![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F12%2Fmline.jpg&w=3840&q=100)

M line

## Your ads can do more.

[Let's talkDiamond](https://www.cavai.com/contact)

Case studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamondCase studiesDiamond

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2023%2F01%2Fcase_logo-adidas-zalando.png&w=256&q=75)

desktopnativemobile

OMO \|Ecommerce

### Adidas x Zalando – Retro World

[Read more](https://www.cavai.com/case-studies/adidas-x-zalando-retro-world)

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F10%2Fomo_case_logo.png&w=256&q=75)

desktopnativemobile

OMO \|Household

### OMO – Kjell & Tore – Talking to people

[Read more](https://www.cavai.com/case-studies/omo-kjell-tore-talking-to-people)

![](<Base64-Image-Removed>)![](https://www.cavai.com/_next/image?url=https%3A%2F%2Fcavai.flywheelsites.com%2Fwp-content%2Fuploads%2F2022%2F02%2Fspankkilogo.png&w=256&q=75)

desktopnativemobile

S-Pankki \|Banking & Finance

### S-Pankki Awareness Campaign

[Read more](https://www.cavai.com/case-studies/s-pankki-awareness-campaign)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

VodafoneZiggo \|Telco

### VodafoneZiggo “Are you a real F1 fan?”

[Read more](https://www.cavai.com/case-studies/vodafone-ziggo)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

BMW Norway \|Automotive

### BMW “Sheer driving pleasure – sharing Christmas cheer”

[Read more](https://www.cavai.com/case-studies/bmw-sheer-driving-pleasure-sharing-christmas-cheer)

![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

desktopnativemobile

TV2 Sumo (now TV2 Play) \|Entertainment

### TV2 Sumo “Movie Guide”

[Read more](https://www.cavai.com/case-studies/tv2-sumo-movie-guide)

[See moreArrow right](https://www.cavai.com/case-studies)

Arrow rightArrow right

## Sign up for our Newsletter

Email addressArrow right

Products & Services

- [Cavai Cloud](https://www.cavai.com/cloud)
- [Cavai Products](https://www.cavai.com/products)
- [Advertisers](https://www.cavai.com/advert)
- [Partners](https://www.cavai.com/partners)

Cavai Cloud

Cavai Products

- [Facebook page](https://www.facebook.com/cavaiadvertising/)
- [Instagram page](https://www.instagram.com/cavai_advertising/)
- [Linkedin page](https://www.linkedin.com/company/cavaiadvertising/)

[Privacy Policy](https://www.cavai.com/privacy-policy)Diamond[Terms of use](https://www.cavai.com/privacy-policy)

Copyright © 2025 Cavai, All Rights Reserved

[iframe](https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LfC3ZceAAAAAOsoAYHxmU3ZCCHTaIEW3-EEKIXl&co=aHR0cHM6Ly93d3cuY2F2YWkuY29tOjQ0Mw..&hl=en&v=jt8Oh2-Ue1u7nEbJQUIdocyd&size=invisible&cb=yhpq7jvpzxd)