[Skip to content](https://nonnasaid.com/#content)

- [0141-648-4848](tel:+441416484848)

[BOOK NOW](http://nonnasaid.com/book/)

[![](https://nonnasaid.com/wp-content/uploads/2023/09/Cream-Nonna@3x.png)](https://nonnasaid.com/)

- [HOME](https://nonnasaid.com/)
- [BOOK](https://nonnasaid.com/book/)
- [MENU](https://nonnasaid.com/menu/)
- [ORDER](https://nonnasaid.com/order/)
- [VOUCHERS](https://nonna-said.vouchercart.com/app/)

- [HOME](https://nonnasaid.com/)
- [BOOK](https://nonnasaid.com/book/)
- [MENU](https://nonnasaid.com/menu/)
- [ORDER](https://nonnasaid.com/order/)
- [VOUCHERS](https://nonna-said.vouchercart.com/app/)

- [0141-648-4848](tel:+441416484848)

[BOOK NOW](http://nonnasaid.com/book/)

[![](https://nonnasaid.com/wp-content/uploads/2023/09/Cream-Nonna@3x.png)](https://nonnasaid.com/)

- [HOME](https://nonnasaid.com/)
- [BOOK](https://nonnasaid.com/book/)
- [MENU](https://nonnasaid.com/menu/)
- [ORDER](https://nonnasaid.com/order/)
- [VOUCHERS](https://nonna-said.vouchercart.com/app/)

- [HOME](https://nonnasaid.com/)
- [BOOK](https://nonnasaid.com/book/)
- [MENU](https://nonnasaid.com/menu/)
- [ORDER](https://nonnasaid.com/order/)
- [VOUCHERS](https://nonna-said.vouchercart.com/app/)

- [NAPOLI-STYLE PIZZA TOPPED TO PERFECTION](https://nonnasaid.com/)

![](https://nonnasaid.com/wp-content/uploads/2023/09/BN-5.png)

![](https://nonnasaid.com/wp-content/uploads/2023/09/BN-6.png)

[ORDER DELIVERY](http://officer2.sg-host.com/order/)

- [NAPOLI-STYLE PIZZA TOPPED TO PERFECTION](https://nonnasaid.com/)

The best pizza in Glasgow?

We use traditional ingredients and proper mozzarella atop Nonna’s original ragu to create proper Napoli-style thin base pizza. Then we add some of the best topping combos that Merchant City has ever seen before baking in our wood-fired ovens.

![](https://nonnasaid.com/wp-content/uploads/2023/09/BN-1.png)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

[Book a Table](http://officer2.sg-host.com/book/)

- [NAPOLI-STYLE PIZZA TOPPED TO PERFECTION](https://nonnasaid.com/)

26 Candleriggs, Glasgow

[0141 648 4848](tel:+441416484848)

[© 2023 Base Scotland All rights Reserved. Design by Rough](https://www.rough.ink/)

[Facebook-f](https://www.facebook.com/NonnaSaidPizza/)[Instagram](https://www.instagram.com/NonnaSaidPizza/)