# Performance Analysis

Consider these performance metrics when rebuilding the website:

## Scores
- **Performance**: 90%
- **Accessibility**: 85%
- **Seo**: 100%
- **BestPractices**: 96%

## Key Metrics
- **firstContentfulPaint**: {"score":0.99,"value":1124.232}
- **largestContentfulPaint**: {"score":0.71,"value":3256.232}
- **totalBlockingTime**: {"score":0.92,"value":176}
- **cumulativeLayoutShift**: {"score":0.99,"value":0.041103920255827035}

## Recommendations
- Improve accessibility to ensure the site is usable by everyone
